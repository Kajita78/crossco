from django.urls import path
from netbox.views.generic import ObjectChangeLogView

from . import models, views

urlpatterns = [
    # CrossConnect URLs
    path('crossconnects/', views.CrossConnectListView.as_view(), name='crossconnect_list'),
    path('crossconnects/add/', views.CrossConnectEditView.as_view(), name='crossconnect_add'),
    path('crossconnects/import/', views.CrossConnectBulkImportView.as_view(), name='crossconnect_import'),
    path('crossconnects/edit/', views.CrossConnectBulkEditView.as_view(), name='crossconnect_bulk_edit'),
    path('crossconnects/delete/', views.CrossConnectBulkDeleteView.as_view(), name='crossconnect_bulk_delete'),
    path('crossconnects/<int:pk>/', views.CrossConnectView.as_view(), name='crossconnect'),
    path('crossconnects/<int:pk>/edit/', views.CrossConnectEditView.as_view(), name='crossconnect_edit'),
    path('crossconnects/<int:pk>/delete/', views.CrossConnectDeleteView.as_view(), name='crossconnect_delete'),
    path('crossconnects/<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='crossconnect_changelog', kwargs={'model': models.CrossConnect}),

    # CrossConnectEndpoint URLs
    path('endpoints/', views.CrossConnectEndpointListView.as_view(), name='crossconnectendpoint_list'),
    path('endpoints/add/', views.CrossConnectEndpointEditView.as_view(), name='crossconnectendpoint_add'),
    path('endpoints/import/', views.CrossConnectEndpointBulkImportView.as_view(), name='crossconnectendpoint_import'),
    path('endpoints/edit/', views.CrossConnectEndpointBulkEditView.as_view(), name='crossconnectendpoint_bulk_edit'),
    path('endpoints/delete/', views.CrossConnectEndpointBulkDeleteView.as_view(), name='crossconnectendpoint_bulk_delete'),
    path('endpoints/<int:pk>/', views.CrossConnectEndpointView.as_view(), name='crossconnectendpoint'),
    path('endpoints/<int:pk>/edit/', views.CrossConnectEndpointEditView.as_view(), name='crossconnectendpoint_edit'),
    path('endpoints/<int:pk>/delete/', views.CrossConnectEndpointDeleteView.as_view(), name='crossconnectendpoint_delete'),
    path('endpoints/<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='crossconnectendpoint_changelog', kwargs={'model': models.CrossConnectEndpoint}),

    # WorkOrder URLs
    path('work-orders/', views.WorkOrderListView.as_view(), name='workorder_list'),
    path('work-orders/add/', views.WorkOrderEditView.as_view(), name='workorder_add'),
    path('work-orders/import/', views.WorkOrderBulkImportView.as_view(), name='workorder_import'),
    path('work-orders/edit/', views.WorkOrderBulkEditView.as_view(), name='workorder_bulk_edit'),
    path('work-orders/delete/', views.WorkOrderBulkDeleteView.as_view(), name='workorder_bulk_delete'),
    path('work-orders/<int:pk>/', views.WorkOrderView.as_view(), name='workorder'),
    path('work-orders/<int:pk>/edit/', views.WorkOrderEditView.as_view(), name='workorder_edit'),
    path('work-orders/<int:pk>/delete/', views.WorkOrderDeleteView.as_view(), name='workorder_delete'),
    path('work-orders/<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='workorder_changelog', kwargs={'model': models.WorkOrder}),

    # BillingRecord URLs
    path('billing-records/', views.BillingRecordListView.as_view(), name='billingrecord_list'),
    path('billing-records/add/', views.BillingRecordEditView.as_view(), name='billingrecord_add'),
    path('billing-records/import/', views.BillingRecordBulkImportView.as_view(), name='billingrecord_import'),
    path('billing-records/edit/', views.BillingRecordBulkEditView.as_view(), name='billingrecord_bulk_edit'),
    path('billing-records/delete/', views.BillingRecordBulkDeleteView.as_view(), name='billingrecord_bulk_delete'),
    path('billing-records/<int:pk>/', views.BillingRecordView.as_view(), name='billingrecord'),
    path('billing-records/<int:pk>/edit/', views.BillingRecordEditView.as_view(), name='billingrecord_edit'),
    path('billing-records/<int:pk>/delete/', views.BillingRecordDeleteView.as_view(), name='billingrecord_delete'),
    path('billing-records/<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='billingrecord_changelog', kwargs={'model': models.BillingRecord}),

    # AuditEvent URLs
    path('audit-events/', views.AuditEventListView.as_view(), name='auditevent_list'),
    path('audit-events/add/', views.AuditEventEditView.as_view(), name='auditevent_add'),
    path('audit-events/import/', views.AuditEventBulkImportView.as_view(), name='auditevent_import'),
    path('audit-events/edit/', views.AuditEventBulkEditView.as_view(), name='auditevent_bulk_edit'),
    path('audit-events/delete/', views.AuditEventBulkDeleteView.as_view(), name='auditevent_bulk_delete'),
    path('audit-events/<int:pk>/', views.AuditEventView.as_view(), name='auditevent'),
    path('audit-events/<int:pk>/edit/', views.AuditEventEditView.as_view(), name='auditevent_edit'),
    path('audit-events/<int:pk>/delete/', views.AuditEventDeleteView.as_view(), name='auditevent_delete'),
    path('audit-events/<int:pk>/changelog/', ObjectChangeLogView.as_view(), name='auditevent_changelog', kwargs={'model': models.AuditEvent}),
]

from netbox.plugins import PluginMenuButton, PluginMenuItem, PluginMenu

menu = PluginMenu(
    label='Cross-Connects',
    groups=(
        (
            'Cross-Connects',
            (
                PluginMenuItem(
                    link='plugins:netbox_crossconnect:crossconnect_list',
                    link_text='Cross-Connects',
                    permissions=['netbox_crossconnect.view_crossconnect'],
                    buttons=(
                        PluginMenuButton(
                            link='plugins:netbox_crossconnect:crossconnect_add',
                            title='Add',
                            icon_class='mdi mdi-plus-thick',
                            permissions=['netbox_crossconnect.add_crossconnect']
                        ),
                        PluginMenuButton(
                            link='plugins:netbox_crossconnect:crossconnect_import',
                            title='Import',
                            icon_class='mdi mdi-upload',
                            permissions=['netbox_crossconnect.add_crossconnect']
                        ),
                    )
                ),
                PluginMenuItem(
                    link='plugins:netbox_crossconnect:crossconnectendpoint_list',
                    link_text='Endpoints',
                    permissions=['netbox_crossconnect.view_crossconnectendpoint'],
                    buttons=(
                        PluginMenuButton(
                            link='plugins:netbox_crossconnect:crossconnectendpoint_add',
                            title='Add',
                            icon_class='mdi mdi-plus-thick',
                            permissions=['netbox_crossconnect.add_crossconnectendpoint']
                        ),
                        PluginMenuButton(
                            link='plugins:netbox_crossconnect:crossconnectendpoint_import',
                            title='Import',
                            icon_class='mdi mdi-upload',
                            permissions=['netbox_crossconnect.add_crossconnectendpoint']
                        ),
                    )
                ),
            )
        ),
        (
            'Operations',
            (
                PluginMenuItem(
                    link='plugins:netbox_crossconnect:workorder_list',
                    link_text='Work Orders',
                    permissions=['netbox_crossconnect.view_workorder'],
                    buttons=(
                        PluginMenuButton(
                            link='plugins:netbox_crossconnect:workorder_add',
                            title='Add',
                            icon_class='mdi mdi-plus-thick',
                            permissions=['netbox_crossconnect.add_workorder']
                        ),
                        PluginMenuButton(
                            link='plugins:netbox_crossconnect:workorder_import',
                            title='Import',
                            icon_class='mdi mdi-upload',
                            permissions=['netbox_crossconnect.add_workorder']
                        ),
                    )
                ),
            )
        ),
        (
            'Billing & Audit',
            (
                PluginMenuItem(
                    link='plugins:netbox_crossconnect:billingrecord_list',
                    link_text='Billing Records',
                    permissions=['netbox_crossconnect.view_billingrecord'],
                    buttons=(
                        PluginMenuButton(
                            link='plugins:netbox_crossconnect:billingrecord_add',
                            title='Add',
                            icon_class='mdi mdi-plus-thick',
                            permissions=['netbox_crossconnect.add_billingrecord']
                        ),
                        PluginMenuButton(
                            link='plugins:netbox_crossconnect:billingrecord_import',
                            title='Import',
                            icon_class='mdi mdi-upload',
                            permissions=['netbox_crossconnect.add_billingrecord']
                        ),
                    )
                ),
                PluginMenuItem(
                    link='plugins:netbox_crossconnect:auditevent_list',
                    link_text='Audit Events',
                    permissions=['netbox_crossconnect.view_auditevent'],
                    buttons=(
                        PluginMenuButton(
                            link='plugins:netbox_crossconnect:auditevent_add',
                            title='Add',
                            icon_class='mdi mdi-plus-thick',
                            permissions=['netbox_crossconnect.add_auditevent']
                        ),
                        PluginMenuButton(
                            link='plugins:netbox_crossconnect:auditevent_import',
                            title='Import',
                            icon_class='mdi mdi-upload',
                            permissions=['netbox_crossconnect.add_auditevent']
                        ),
                    )
                ),
            )
        ),
    )
)

from rest_framework import serializers
from netbox.api.serializers import NetBoxModelSerializer
from netbox.api.fields import RelatedObjectCountField

from netbox_crossconnect.models import (
    CrossConnect, CrossConnectEndpoint, WorkOrder, BillingRecord, AuditEvent
)


class CrossConnectSerializer(NetBoxModelSerializer):
    """REST API serializer for CrossConnect model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:crossconnect-detail'
    )
    tenant = serializers.SerializerMethodField()
    provider = serializers.SerializerMethodField()
    site = serializers.SerializerMethodField()
    location = serializers.SerializerMethodField()
    endpoint_count = RelatedObjectCountField('endpoints')
    work_order_count = RelatedObjectCountField('work_orders')
    billing_record_count = RelatedObjectCountField('billing_records')

    class Meta:
        model = CrossConnect
        fields = [
            'id', 'url', 'display', 'reference', 'tenant', 'provider', 'site',
            'location', 'type', 'capacity', 'status', 'order_date',
            'delivery_date', 'monthly_cost', 'one_time_cost', 'comments',
            'endpoint_count', 'work_order_count', 'billing_record_count',
            'tags', 'custom_fields', 'created', 'last_updated'
        ]

    def get_tenant(self, obj):
        if obj.tenant:
            return {
                'id': obj.tenant.id,
                'name': obj.tenant.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/tenancy/tenants/{obj.tenant.id}/'
                )
            }
        return None

    def get_provider(self, obj):
        if obj.provider:
            return {
                'id': obj.provider.id,
                'name': obj.provider.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/circuits/providers/{obj.provider.id}/'
                )
            }
        return None

    def get_site(self, obj):
        return {
            'id': obj.site.id,
            'name': obj.site.name,
            'url': self.context['request'].build_absolute_uri(
                f'/api/dcim/sites/{obj.site.id}/'
            )
        }

    def get_location(self, obj):
        if obj.location:
            return {
                'id': obj.location.id,
                'name': obj.location.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/dcim/locations/{obj.location.id}/'
                )
            }
        return None


class CrossConnectEndpointSerializer(NetBoxModelSerializer):
    """REST API serializer for CrossConnectEndpoint model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:crossconnectendpoint-detail'
    )
    crossconnect = serializers.SerializerMethodField()
    rack = serializers.SerializerMethodField()

    class Meta:
        model = CrossConnectEndpoint
        fields = [
            'id', 'url', 'display', 'crossconnect', 'side', 'endpoint_type',
            'rack', 'rack_position', 'port_label', 'patch_label', 'cable_length',
            'cable_color', 'polarity', 'comments', 'tags', 'custom_fields',
            'created', 'last_updated'
        ]

    def get_crossconnect(self, obj):
        return {
            'id': obj.crossconnect.id,
            'reference': obj.crossconnect.reference,
            'url': self.context['request'].build_absolute_uri(
                f'/api/plugins/crossconnect/crossconnects/{obj.crossconnect.id}/'
            )
        }

    def get_rack(self, obj):
        if obj.rack:
            return {
                'id': obj.rack.id,
                'name': obj.rack.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/dcim/racks/{obj.rack.id}/'
                )
            }
        return None


class WorkOrderSerializer(NetBoxModelSerializer):
    """REST API serializer for WorkOrder model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:workorder-detail'
    )
    crossconnect = serializers.SerializerMethodField()

    class Meta:
        model = WorkOrder
        fields = [
            'id', 'url', 'display', 'order_number', 'crossconnect', 'technician',
            'action', 'scheduled_date', 'completed_date', 'before_state',
            'after_state', 'is_validated', 'photo_url', 'comments', 'tags',
            'custom_fields', 'created', 'last_updated'
        ]

    def get_crossconnect(self, obj):
        return {
            'id': obj.crossconnect.id,
            'reference': obj.crossconnect.reference,
            'url': self.context['request'].build_absolute_uri(
                f'/api/plugins/crossconnect/crossconnects/{obj.crossconnect.id}/'
            )
        }


class BillingRecordSerializer(NetBoxModelSerializer):
    """REST API serializer for BillingRecord model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:billingrecord-detail'
    )
    crossconnect = serializers.SerializerMethodField()
    provider = serializers.SerializerMethodField()

    class Meta:
        model = BillingRecord
        fields = [
            'id', 'url', 'display', 'crossconnect', 'provider', 'order_reference',
            'monthly_charge', 'one_time_charge', 'billing_start_date',
            'billing_end_date', 'expected_charge', 'actual_charge', 'variance',
            'invoice_number', 'comments', 'tags', 'custom_fields', 'created',
            'last_updated'
        ]

    def get_crossconnect(self, obj):
        return {
            'id': obj.crossconnect.id,
            'reference': obj.crossconnect.reference,
            'url': self.context['request'].build_absolute_uri(
                f'/api/plugins/crossconnect/crossconnects/{obj.crossconnect.id}/'
            )
        }

    def get_provider(self, obj):
        if obj.provider:
            return {
                'id': obj.provider.id,
                'name': obj.provider.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/circuits/providers/{obj.provider.id}/'
                )
            }
        return None


class AuditEventSerializer(NetBoxModelSerializer):
    """REST API serializer for AuditEvent model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:auditevent-detail'
    )
    crossconnect = serializers.SerializerMethodField()
    user = serializers.SerializerMethodField()

    class Meta:
        model = AuditEvent
        fields = [
            'id', 'url', 'display', 'crossconnect', 'user', 'timestamp',
            'field_changed', 'old_value', 'new_value', 'reason', 'comments',
            'tags', 'custom_fields', 'created', 'last_updated'
        ]

    def get_crossconnect(self, obj):
        return {
            'id': obj.crossconnect.id,
            'reference': obj.crossconnect.reference,
            'url': self.context['request'].build_absolute_uri(
                f'/api/plugins/crossconnect/crossconnects/{obj.crossconnect.id}/'
            )
        }

    def get_user(self, obj):
        if obj.user:
            return {
                'id': obj.user.id,
                'username': obj.user.username,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/users/users/{obj.user.id}/'
                )
            }
        return None

from netbox.api.routers import NetBoxRouter
from . import views

app_name = 'netbox_crossconnect'

router = NetBoxRouter()
router.register('crossconnects', views.CrossConnectViewSet)
router.register('endpoints', views.CrossConnectEndpointViewSet)
router.register('work-orders', views.WorkOrderViewSet)
router.register('billing-records', views.BillingRecordViewSet)
router.register('audit-events', views.AuditEventViewSet)

urlpatterns = router.urls

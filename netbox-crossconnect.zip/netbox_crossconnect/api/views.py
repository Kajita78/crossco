from netbox.api.viewsets import NetBoxModelViewSet

from netbox_crossconnect.models import (
    CrossConnect, CrossConnectEndpoint, WorkOrder, BillingRecord, AuditEvent
)
from netbox_crossconnect.filtersets import (
    CrossConnectFilterSet, CrossConnectEndpointFilterSet, WorkOrderFilterSet,
    BillingRecordFilterSet, AuditEventFilterSet
)
from .serializers import (
    CrossConnectSerializer, CrossConnectEndpointSerializer, WorkOrderSerializer,
    BillingRecordSerializer, AuditEventSerializer
)


class CrossConnectViewSet(NetBoxModelViewSet):
    """REST API viewset for CrossConnect model"""
    queryset = CrossConnect.objects.prefetch_related(
        'tenant', 'provider', 'site', 'location', 'endpoints', 'tags'
    )
    serializer_class = CrossConnectSerializer
    filterset_class = CrossConnectFilterSet


class CrossConnectEndpointViewSet(NetBoxModelViewSet):
    """REST API viewset for CrossConnectEndpoint model"""
    queryset = CrossConnectEndpoint.objects.prefetch_related(
        'crossconnect', 'rack', 'tags'
    )
    serializer_class = CrossConnectEndpointSerializer
    filterset_class = CrossConnectEndpointFilterSet


class WorkOrderViewSet(NetBoxModelViewSet):
    """REST API viewset for WorkOrder model"""
    queryset = WorkOrder.objects.prefetch_related('crossconnect', 'tags')
    serializer_class = WorkOrderSerializer
    filterset_class = WorkOrderFilterSet


class BillingRecordViewSet(NetBoxModelViewSet):
    """REST API viewset for BillingRecord model"""
    queryset = BillingRecord.objects.prefetch_related(
        'crossconnect', 'provider', 'tags'
    )
    serializer_class = BillingRecordSerializer
    filterset_class = BillingRecordFilterSet


class AuditEventViewSet(NetBoxModelViewSet):
    """REST API viewset for AuditEvent model"""
    queryset = AuditEvent.objects.prefetch_related(
        'crossconnect', 'user', 'tags'
    )
    serializer_class = AuditEventSerializer
    filterset_class = AuditEventFilterSet

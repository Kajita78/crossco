from netbox.views import generic
from utilities.views import ViewTab, register_model_view

from . import filtersets, forms, tables
from .models import CrossConnect, CrossConnectEndpoint, WorkOrder, BillingRecord, AuditEvent


# CrossConnect Views

class CrossConnectListView(generic.ObjectListView):
    queryset = CrossConnect.objects.all()
    table = tables.CrossConnectTable
    filterset = filtersets.CrossConnectFilterSet
    filterset_form = forms.CrossConnectFilterForm


@register_model_view(CrossConnect)
class CrossConnectView(generic.ObjectView):
    queryset = CrossConnect.objects.all()

    def get_extra_context(self, request, instance):
        endpoints = instance.endpoints.all()
        work_orders = instance.work_orders.all()[:10]
        billing_records = instance.billing_records.all()[:10]
        audit_events = instance.audit_events.all()[:10]

        return {
            'endpoints': endpoints,
            'work_orders': work_orders,
            'billing_records': billing_records,
            'audit_events': audit_events,
        }


@register_model_view(CrossConnect, 'edit')
class CrossConnectEditView(generic.ObjectEditView):
    queryset = CrossConnect.objects.all()
    form = forms.CrossConnectForm


@register_model_view(CrossConnect, 'delete')
class CrossConnectDeleteView(generic.ObjectDeleteView):
    queryset = CrossConnect.objects.all()


class CrossConnectBulkImportView(generic.BulkImportView):
    queryset = CrossConnect.objects.all()
    model_form = forms.CrossConnectForm


class CrossConnectBulkEditView(generic.BulkEditView):
    queryset = CrossConnect.objects.all()
    filterset = filtersets.CrossConnectFilterSet
    table = tables.CrossConnectTable
    form = forms.CrossConnectForm


class CrossConnectBulkDeleteView(generic.BulkDeleteView):
    queryset = CrossConnect.objects.all()
    filterset = filtersets.CrossConnectFilterSet
    table = tables.CrossConnectTable


# CrossConnectEndpoint Views

class CrossConnectEndpointListView(generic.ObjectListView):
    queryset = CrossConnectEndpoint.objects.all()
    table = tables.CrossConnectEndpointTable
    filterset = filtersets.CrossConnectEndpointFilterSet
    filterset_form = forms.CrossConnectEndpointFilterForm


@register_model_view(CrossConnectEndpoint)
class CrossConnectEndpointView(generic.ObjectView):
    queryset = CrossConnectEndpoint.objects.all()


@register_model_view(CrossConnectEndpoint, 'edit')
class CrossConnectEndpointEditView(generic.ObjectEditView):
    queryset = CrossConnectEndpoint.objects.all()
    form = forms.CrossConnectEndpointForm


@register_model_view(CrossConnectEndpoint, 'delete')
class CrossConnectEndpointDeleteView(generic.ObjectDeleteView):
    queryset = CrossConnectEndpoint.objects.all()


class CrossConnectEndpointBulkImportView(generic.BulkImportView):
    queryset = CrossConnectEndpoint.objects.all()
    model_form = forms.CrossConnectEndpointForm


class CrossConnectEndpointBulkEditView(generic.BulkEditView):
    queryset = CrossConnectEndpoint.objects.all()
    filterset = filtersets.CrossConnectEndpointFilterSet
    table = tables.CrossConnectEndpointTable
    form = forms.CrossConnectEndpointForm


class CrossConnectEndpointBulkDeleteView(generic.BulkDeleteView):
    queryset = CrossConnectEndpoint.objects.all()
    filterset = filtersets.CrossConnectEndpointFilterSet
    table = tables.CrossConnectEndpointTable


# WorkOrder Views

class WorkOrderListView(generic.ObjectListView):
    queryset = WorkOrder.objects.all()
    table = tables.WorkOrderTable
    filterset = filtersets.WorkOrderFilterSet
    filterset_form = forms.WorkOrderFilterForm


@register_model_view(WorkOrder)
class WorkOrderView(generic.ObjectView):
    queryset = WorkOrder.objects.all()


@register_model_view(WorkOrder, 'edit')
class WorkOrderEditView(generic.ObjectEditView):
    queryset = WorkOrder.objects.all()
    form = forms.WorkOrderForm


@register_model_view(WorkOrder, 'delete')
class WorkOrderDeleteView(generic.ObjectDeleteView):
    queryset = WorkOrder.objects.all()


class WorkOrderBulkImportView(generic.BulkImportView):
    queryset = WorkOrder.objects.all()
    model_form = forms.WorkOrderForm


class WorkOrderBulkEditView(generic.BulkEditView):
    queryset = WorkOrder.objects.all()
    filterset = filtersets.WorkOrderFilterSet
    table = tables.WorkOrderTable
    form = forms.WorkOrderForm


class WorkOrderBulkDeleteView(generic.BulkDeleteView):
    queryset = WorkOrder.objects.all()
    filterset = filtersets.WorkOrderFilterSet
    table = tables.WorkOrderTable


# BillingRecord Views

class BillingRecordListView(generic.ObjectListView):
    queryset = BillingRecord.objects.all()
    table = tables.BillingRecordTable
    filterset = filtersets.BillingRecordFilterSet
    filterset_form = forms.BillingRecordFilterForm


@register_model_view(BillingRecord)
class BillingRecordView(generic.ObjectView):
    queryset = BillingRecord.objects.all()


@register_model_view(BillingRecord, 'edit')
class BillingRecordEditView(generic.ObjectEditView):
    queryset = BillingRecord.objects.all()
    form = forms.BillingRecordForm


@register_model_view(BillingRecord, 'delete')
class BillingRecordDeleteView(generic.ObjectDeleteView):
    queryset = BillingRecord.objects.all()


class BillingRecordBulkImportView(generic.BulkImportView):
    queryset = BillingRecord.objects.all()
    model_form = forms.BillingRecordForm


class BillingRecordBulkEditView(generic.BulkEditView):
    queryset = BillingRecord.objects.all()
    filterset = filtersets.BillingRecordFilterSet
    table = tables.BillingRecordTable
    form = forms.BillingRecordForm


class BillingRecordBulkDeleteView(generic.BulkDeleteView):
    queryset = BillingRecord.objects.all()
    filterset = filtersets.BillingRecordFilterSet
    table = tables.BillingRecordTable


# AuditEvent Views

class AuditEventListView(generic.ObjectListView):
    queryset = AuditEvent.objects.all()
    table = tables.AuditEventTable
    filterset = filtersets.AuditEventFilterSet
    filterset_form = forms.AuditEventFilterForm


@register_model_view(AuditEvent)
class AuditEventView(generic.ObjectView):
    queryset = AuditEvent.objects.all()


@register_model_view(AuditEvent, 'edit')
class AuditEventEditView(generic.ObjectEditView):
    queryset = AuditEvent.objects.all()
    form = forms.AuditEventForm


@register_model_view(AuditEvent, 'delete')
class AuditEventDeleteView(generic.ObjectDeleteView):
    queryset = AuditEvent.objects.all()


class AuditEventBulkImportView(generic.BulkImportView):
    queryset = AuditEvent.objects.all()
    model_form = forms.AuditEventForm


class AuditEventBulkEditView(generic.BulkEditView):
    queryset = AuditEvent.objects.all()
    filterset = filtersets.AuditEventFilterSet
    table = tables.AuditEventTable
    form = forms.AuditEventForm


class AuditEventBulkDeleteView(generic.BulkDeleteView):
    queryset = AuditEvent.objects.all()
    filterset = filtersets.AuditEventFilterSet
    table = tables.AuditEventTable

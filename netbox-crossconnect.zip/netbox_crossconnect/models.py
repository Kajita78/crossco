from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ValidationError
from django.db import models
from django.urls import reverse
from netbox.models import NetBoxModel
from utilities.choices import ChoiceSet


class CrossConnectTypeChoices(ChoiceSet):
    key = 'CrossConnect.type'

    TYPE_COPPER = 'copper'
    TYPE_FIBER_SM = 'fiber-sm'
    TYPE_FIBER_MM = 'fiber-mm'

    CHOICES = [
        (TYPE_COPPER, 'Copper'),
        (TYPE_FIBER_SM, 'Fiber Single-Mode'),
        (TYPE_FIBER_MM, 'Fiber Multi-Mode'),
    ]


class CrossConnectCapacityChoices(ChoiceSet):
    key = 'CrossConnect.capacity'

    CAPACITY_1G = '1g'
    CAPACITY_10G = '10g'
    CAPACITY_40G = '40g'
    CAPACITY_100G = '100g'
    CAPACITY_400G = '400g'
    CAPACITY_OTHER = 'other'

    CHOICES = [
        (CAPACITY_1G, '1 Gbps'),
        (CAPACITY_10G, '10 Gbps'),
        (CAPACITY_40G, '40 Gbps'),
        (CAPACITY_100G, '100 Gbps'),
        (CAPACITY_400G, '400 Gbps'),
        (CAPACITY_OTHER, 'Other'),
    ]


class CrossConnectStatusChoices(ChoiceSet):
    key = 'CrossConnect.status'

    STATUS_REQUESTED = 'requested'
    STATUS_ORDERED = 'ordered'
    STATUS_IN_PROGRESS = 'in-progress'
    STATUS_ACTIVE = 'active'
    STATUS_SUSPENDED = 'suspended'
    STATUS_TERMINATED = 'terminated'

    CHOICES = [
        (STATUS_REQUESTED, 'Requested'),
        (STATUS_ORDERED, 'Ordered'),
        (STATUS_IN_PROGRESS, 'In Progress'),
        (STATUS_ACTIVE, 'Active'),
        (STATUS_SUSPENDED, 'Suspended'),
        (STATUS_TERMINATED, 'Terminated'),
    ]


class EndpointSideChoices(ChoiceSet):
    key = 'CrossConnectEndpoint.side'

    SIDE_A = 'a'
    SIDE_B = 'b'

    CHOICES = [
        (SIDE_A, 'Side A'),
        (SIDE_B, 'Side B'),
    ]


class EndpointTypeChoices(ChoiceSet):
    key = 'CrossConnectEndpoint.endpoint_type'

    TYPE_PATCH_PANEL = 'patch-panel'
    TYPE_DEVICE_INTERFACE = 'device-interface'
    TYPE_CIRCUIT_TERMINATION = 'circuit-termination'
    TYPE_FREE_POSITION = 'free-position'

    CHOICES = [
        (TYPE_PATCH_PANEL, 'Patch Panel'),
        (TYPE_DEVICE_INTERFACE, 'Device Interface'),
        (TYPE_CIRCUIT_TERMINATION, 'Circuit Termination'),
        (TYPE_FREE_POSITION, 'Free Position'),
    ]


class WorkOrderActionChoices(ChoiceSet):
    key = 'WorkOrder.action'

    ACTION_CREATE = 'create'
    ACTION_MOVE = 'move'
    ACTION_ADD = 'add'
    ACTION_CHANGE = 'change'
    ACTION_DELETE = 'delete'

    CHOICES = [
        (ACTION_CREATE, 'Create'),
        (ACTION_MOVE, 'Move'),
        (ACTION_ADD, 'Add'),
        (ACTION_CHANGE, 'Change'),
        (ACTION_DELETE, 'Delete'),
    ]


class CrossConnect(NetBoxModel):
    """
    Represents a cross-connect request and its lifecycle.
    Links customer, operator, location, and tracks status and billing.
    """
    reference = models.CharField(
        max_length=100,
        unique=True,
        help_text='Unique reference for this cross-connect'
    )
    tenant = models.ForeignKey(
        to='tenancy.Tenant',
        on_delete=models.PROTECT,
        related_name='crossconnects',
        blank=True,
        null=True,
        help_text='Customer/Tenant'
    )
    provider = models.ForeignKey(
        to='circuits.Provider',
        on_delete=models.PROTECT,
        related_name='crossconnects',
        blank=True,
        null=True,
        help_text='Service provider/Operator'
    )
    site = models.ForeignKey(
        to='dcim.Site',
        on_delete=models.PROTECT,
        related_name='crossconnects',
        help_text='Datacenter site'
    )
    location = models.ForeignKey(
        to='dcim.Location',
        on_delete=models.PROTECT,
        related_name='crossconnects',
        blank=True,
        null=True,
        help_text='Room/MMR within the site'
    )
    type = models.CharField(
        max_length=50,
        choices=CrossConnectTypeChoices,
        help_text='Cable type'
    )
    capacity = models.CharField(
        max_length=50,
        choices=CrossConnectCapacityChoices,
        help_text='Bandwidth capacity'
    )
    status = models.CharField(
        max_length=50,
        choices=CrossConnectStatusChoices,
        default=CrossConnectStatusChoices.STATUS_REQUESTED,
        help_text='Current status'
    )
    order_date = models.DateField(
        blank=True,
        null=True,
        help_text='Date when ordered'
    )
    delivery_date = models.DateField(
        blank=True,
        null=True,
        help_text='Expected or actual delivery date'
    )
    monthly_cost = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        help_text='Monthly recurring charge (MRC)'
    )
    one_time_cost = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        help_text='One-time installation charge (NRC)'
    )
    comments = models.TextField(
        blank=True,
        help_text='Additional notes'
    )

    class Meta:
        ordering = ['reference']
        verbose_name = 'Cross-Connect'
        verbose_name_plural = 'Cross-Connects'

    def __str__(self):
        return self.reference

    def get_absolute_url(self):
        return reverse('plugins:netbox_crossconnect:crossconnect', args=[self.pk])

    def get_status_color(self):
        """Return Bootstrap color class for status badge"""
        colors = {
            CrossConnectStatusChoices.STATUS_REQUESTED: 'secondary',
            CrossConnectStatusChoices.STATUS_ORDERED: 'info',
            CrossConnectStatusChoices.STATUS_IN_PROGRESS: 'warning',
            CrossConnectStatusChoices.STATUS_ACTIVE: 'success',
            CrossConnectStatusChoices.STATUS_SUSPENDED: 'danger',
            CrossConnectStatusChoices.STATUS_TERMINATED: 'dark',
        }
        return colors.get(self.status, 'secondary')


class CrossConnectEndpoint(NetBoxModel):
    """
    Represents one end (A or B) of a cross-connect.
    Can reference patch panels, device interfaces, circuit terminations, or free positions.
    """
    crossconnect = models.ForeignKey(
        to=CrossConnect,
        on_delete=models.CASCADE,
        related_name='endpoints'
    )
    side = models.CharField(
        max_length=10,
        choices=EndpointSideChoices,
        help_text='Side A or B'
    )
    endpoint_type = models.CharField(
        max_length=50,
        choices=EndpointTypeChoices,
        help_text='Type of endpoint'
    )

    # Generic foreign key to allow linking to various NetBox objects
    assigned_object_type = models.ForeignKey(
        to=ContentType,
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name='+'
    )
    assigned_object_id = models.PositiveBigIntegerField(
        blank=True,
        null=True
    )
    assigned_object = GenericForeignKey(
        ct_field='assigned_object_type',
        fk_field='assigned_object_id'
    )

    # Physical details
    rack = models.ForeignKey(
        to='dcim.Rack',
        on_delete=models.SET_NULL,
        related_name='crossconnect_endpoints',
        blank=True,
        null=True,
        help_text='Rack location'
    )
    rack_position = models.CharField(
        max_length=50,
        blank=True,
        help_text='Position in rack (U or panel position)'
    )
    port_label = models.CharField(
        max_length=100,
        blank=True,
        help_text='Port or connector label'
    )
    patch_label = models.CharField(
        max_length=100,
        blank=True,
        help_text='Patch cable identification'
    )
    cable_length = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        blank=True,
        null=True,
        help_text='Cable length in meters'
    )
    cable_color = models.CharField(
        max_length=50,
        blank=True,
        help_text='Cable color'
    )
    polarity = models.CharField(
        max_length=50,
        blank=True,
        help_text='Fiber polarity or pinout'
    )
    comments = models.TextField(
        blank=True
    )

    class Meta:
        ordering = ['crossconnect', 'side']
        unique_together = [['crossconnect', 'side']]
        verbose_name = 'Cross-Connect Endpoint'
        verbose_name_plural = 'Cross-Connect Endpoints'

    def __str__(self):
        return f'{self.crossconnect.reference} - Side {self.side.upper()}'

    def get_absolute_url(self):
        return reverse('plugins:netbox_crossconnect:crossconnectendpoint', args=[self.pk])


class WorkOrder(NetBoxModel):
    """
    Tracks physical interventions and changes to cross-connects.
    Records who did what, when, and provides before/after traceability.
    """
    order_number = models.CharField(
        max_length=100,
        unique=True,
        help_text='Work order or ticket number'
    )
    crossconnect = models.ForeignKey(
        to=CrossConnect,
        on_delete=models.CASCADE,
        related_name='work_orders'
    )
    technician = models.CharField(
        max_length=200,
        blank=True,
        help_text='Technician name or ID'
    )
    action = models.CharField(
        max_length=50,
        choices=WorkOrderActionChoices,
        help_text='Type of action performed'
    )
    scheduled_date = models.DateTimeField(
        blank=True,
        null=True,
        help_text='Scheduled intervention date'
    )
    completed_date = models.DateTimeField(
        blank=True,
        null=True,
        help_text='Actual completion date'
    )
    before_state = models.TextField(
        blank=True,
        help_text='State before intervention'
    )
    after_state = models.TextField(
        blank=True,
        help_text='State after intervention'
    )
    is_validated = models.BooleanField(
        default=False,
        help_text='Has been validated by supervisor'
    )
    photo_url = models.URLField(
        blank=True,
        help_text='Link to proof photo or documentation'
    )
    comments = models.TextField(
        blank=True
    )

    class Meta:
        ordering = ['-completed_date', '-scheduled_date']
        verbose_name = 'Work Order'
        verbose_name_plural = 'Work Orders'

    def __str__(self):
        return f'{self.order_number} - {self.crossconnect.reference}'

    def get_absolute_url(self):
        return reverse('plugins:netbox_crossconnect:workorder', args=[self.pk])


class BillingRecord(NetBoxModel):
    """
    Tracks billing information for cross-connects.
    Records charges, compares expected vs actual billing.
    """
    crossconnect = models.ForeignKey(
        to=CrossConnect,
        on_delete=models.CASCADE,
        related_name='billing_records'
    )
    provider = models.ForeignKey(
        to='circuits.Provider',
        on_delete=models.PROTECT,
        related_name='billing_records',
        blank=True,
        null=True,
        help_text='Billing provider'
    )
    order_reference = models.CharField(
        max_length=100,
        blank=True,
        help_text='Provider order reference'
    )
    monthly_charge = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        help_text='Monthly recurring charge (MRC)'
    )
    one_time_charge = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        help_text='One-time charge (NRC)'
    )
    billing_start_date = models.DateField(
        blank=True,
        null=True,
        help_text='Billing start date'
    )
    billing_end_date = models.DateField(
        blank=True,
        null=True,
        help_text='Billing end date'
    )
    expected_charge = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        help_text='Expected monthly charge'
    )
    actual_charge = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        help_text='Actual billed amount'
    )
    variance = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        editable=False,
        help_text='Difference between expected and actual'
    )
    invoice_number = models.CharField(
        max_length=100,
        blank=True,
        help_text='Invoice reference'
    )
    comments = models.TextField(
        blank=True
    )

    class Meta:
        ordering = ['-billing_start_date']
        verbose_name = 'Billing Record'
        verbose_name_plural = 'Billing Records'

    def __str__(self):
        return f'{self.crossconnect.reference} - {self.billing_start_date or "No date"}'

    def get_absolute_url(self):
        return reverse('plugins:netbox_crossconnect:billingrecord', args=[self.pk])

    def save(self, *args, **kwargs):
        # Calculate variance automatically
        if self.expected_charge is not None and self.actual_charge is not None:
            self.variance = self.actual_charge - self.expected_charge
        super().save(*args, **kwargs)


class AuditEvent(NetBoxModel):
    """
    Audit trail for cross-connect changes.
    Tracks who changed what, when, and why.
    """
    crossconnect = models.ForeignKey(
        to=CrossConnect,
        on_delete=models.CASCADE,
        related_name='audit_events'
    )
    user = models.ForeignKey(
        to='users.User',
        on_delete=models.SET_NULL,
        related_name='crossconnect_audit_events',
        blank=True,
        null=True,
        help_text='User who made the change'
    )
    timestamp = models.DateTimeField(
        auto_now_add=True,
        help_text='When the change occurred'
    )
    field_changed = models.CharField(
        max_length=100,
        blank=True,
        help_text='Field or aspect that changed'
    )
    old_value = models.TextField(
        blank=True,
        help_text='Previous value'
    )
    new_value = models.TextField(
        blank=True,
        help_text='New value'
    )
    reason = models.TextField(
        blank=True,
        help_text='Reason for change'
    )
    comments = models.TextField(
        blank=True
    )

    class Meta:
        ordering = ['-timestamp']
        verbose_name = 'Audit Event'
        verbose_name_plural = 'Audit Events'

    def __str__(self):
        return f'{self.crossconnect.reference} - {self.timestamp}'

    def get_absolute_url(self):
        return reverse('plugins:netbox_crossconnect:auditevent', args=[self.pk])

from netbox.filtersets import NetBoxModelFilterSet
from django.db.models import Q
import django_filters

from .models import (
    CrossConnect, CrossConnectEndpoint, WorkOrder, BillingRecord, AuditEvent,
    CrossConnectTypeChoices, CrossConnectCapacityChoices, CrossConnectStatusChoices,
    EndpointSideChoices, EndpointTypeChoices, WorkOrderActionChoices
)


class CrossConnectFilterSet(NetBoxModelFilterSet):
    """FilterSet for CrossConnect model"""

    reference = django_filters.CharFilter(
        lookup_expr='icontains',
        label='Reference (contains)'
    )
    tenant_id = django_filters.ModelMultipleChoiceFilter(
        field_name='tenant',
        queryset=lambda request: __import__('tenancy.models', fromlist=['Tenant']).Tenant.objects.all(),
        label='Customer/Tenant'
    )
    provider_id = django_filters.ModelMultipleChoiceFilter(
        field_name='provider',
        queryset=lambda request: __import__('circuits.models', fromlist=['Provider']).Provider.objects.all(),
        label='Operator/Provider'
    )
    site_id = django_filters.ModelMultipleChoiceFilter(
        field_name='site',
        queryset=lambda request: __import__('dcim.models', fromlist=['Site']).Site.objects.all(),
        label='Site'
    )
    location_id = django_filters.ModelMultipleChoiceFilter(
        field_name='location',
        queryset=lambda request: __import__('dcim.models', fromlist=['Location']).Location.objects.all(),
        label='Location'
    )
    type = django_filters.MultipleChoiceFilter(
        choices=CrossConnectTypeChoices,
        null_value=None
    )
    capacity = django_filters.MultipleChoiceFilter(
        choices=CrossConnectCapacityChoices,
        null_value=None
    )
    status = django_filters.MultipleChoiceFilter(
        choices=CrossConnectStatusChoices,
        null_value=None
    )
    order_date = django_filters.DateFilter()
    order_date__gte = django_filters.DateFilter(
        field_name='order_date',
        lookup_expr='gte',
        label='Order date after'
    )
    order_date__lte = django_filters.DateFilter(
        field_name='order_date',
        lookup_expr='lte',
        label='Order date before'
    )
    delivery_date = django_filters.DateFilter()
    delivery_date__gte = django_filters.DateFilter(
        field_name='delivery_date',
        lookup_expr='gte',
        label='Delivery date after'
    )
    delivery_date__lte = django_filters.DateFilter(
        field_name='delivery_date',
        lookup_expr='lte',
        label='Delivery date before'
    )

    class Meta:
        model = CrossConnect
        fields = ['id', 'reference', 'type', 'capacity', 'status', 'comments']

    def search(self, queryset, name, value):
        """Search across multiple fields"""
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(reference__icontains=value) |
            Q(comments__icontains=value)
        )


class CrossConnectEndpointFilterSet(NetBoxModelFilterSet):
    """FilterSet for CrossConnectEndpoint model"""

    crossconnect_id = django_filters.ModelMultipleChoiceFilter(
        field_name='crossconnect',
        queryset=CrossConnect.objects.all(),
        label='Cross-Connect'
    )
    side = django_filters.MultipleChoiceFilter(
        choices=EndpointSideChoices,
        null_value=None
    )
    endpoint_type = django_filters.MultipleChoiceFilter(
        choices=EndpointTypeChoices,
        null_value=None
    )
    rack_id = django_filters.ModelMultipleChoiceFilter(
        field_name='rack',
        queryset=lambda request: __import__('dcim.models', fromlist=['Rack']).Rack.objects.all(),
        label='Rack'
    )
    port_label = django_filters.CharFilter(
        lookup_expr='icontains',
        label='Port label (contains)'
    )
    patch_label = django_filters.CharFilter(
        lookup_expr='icontains',
        label='Patch label (contains)'
    )
    cable_color = django_filters.CharFilter(
        lookup_expr='icontains',
        label='Cable color (contains)'
    )

    class Meta:
        model = CrossConnectEndpoint
        fields = ['id', 'side', 'endpoint_type', 'port_label', 'patch_label', 'cable_color', 'comments']

    def search(self, queryset, name, value):
        """Search across multiple fields"""
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(port_label__icontains=value) |
            Q(patch_label__icontains=value) |
            Q(cable_color__icontains=value) |
            Q(comments__icontains=value)
        )


class WorkOrderFilterSet(NetBoxModelFilterSet):
    """FilterSet for WorkOrder model"""

    order_number = django_filters.CharFilter(
        lookup_expr='icontains',
        label='Order number (contains)'
    )
    crossconnect_id = django_filters.ModelMultipleChoiceFilter(
        field_name='crossconnect',
        queryset=CrossConnect.objects.all(),
        label='Cross-Connect'
    )
    technician = django_filters.CharFilter(
        lookup_expr='icontains',
        label='Technician (contains)'
    )
    action = django_filters.MultipleChoiceFilter(
        choices=WorkOrderActionChoices,
        null_value=None
    )
    is_validated = django_filters.BooleanFilter()
    scheduled_date = django_filters.DateTimeFilter()
    scheduled_date__gte = django_filters.DateTimeFilter(
        field_name='scheduled_date',
        lookup_expr='gte',
        label='Scheduled after'
    )
    scheduled_date__lte = django_filters.DateTimeFilter(
        field_name='scheduled_date',
        lookup_expr='lte',
        label='Scheduled before'
    )
    completed_date = django_filters.DateTimeFilter()
    completed_date__gte = django_filters.DateTimeFilter(
        field_name='completed_date',
        lookup_expr='gte',
        label='Completed after'
    )
    completed_date__lte = django_filters.DateTimeFilter(
        field_name='completed_date',
        lookup_expr='lte',
        label='Completed before'
    )

    class Meta:
        model = WorkOrder
        fields = ['id', 'order_number', 'technician', 'action', 'is_validated', 'comments']

    def search(self, queryset, name, value):
        """Search across multiple fields"""
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(order_number__icontains=value) |
            Q(technician__icontains=value) |
            Q(before_state__icontains=value) |
            Q(after_state__icontains=value) |
            Q(comments__icontains=value)
        )


class BillingRecordFilterSet(NetBoxModelFilterSet):
    """FilterSet for BillingRecord model"""

    crossconnect_id = django_filters.ModelMultipleChoiceFilter(
        field_name='crossconnect',
        queryset=CrossConnect.objects.all(),
        label='Cross-Connect'
    )
    provider_id = django_filters.ModelMultipleChoiceFilter(
        field_name='provider',
        queryset=lambda request: __import__('circuits.models', fromlist=['Provider']).Provider.objects.all(),
        label='Provider'
    )
    order_reference = django_filters.CharFilter(
        lookup_expr='icontains',
        label='Order reference (contains)'
    )
    invoice_number = django_filters.CharFilter(
        lookup_expr='icontains',
        label='Invoice number (contains)'
    )
    billing_start_date = django_filters.DateFilter()
    billing_start_date__gte = django_filters.DateFilter(
        field_name='billing_start_date',
        lookup_expr='gte',
        label='Start date after'
    )
    billing_start_date__lte = django_filters.DateFilter(
        field_name='billing_start_date',
        lookup_expr='lte',
        label='Start date before'
    )
    billing_end_date = django_filters.DateFilter()
    billing_end_date__gte = django_filters.DateFilter(
        field_name='billing_end_date',
        lookup_expr='gte',
        label='End date after'
    )
    billing_end_date__lte = django_filters.DateFilter(
        field_name='billing_end_date',
        lookup_expr='lte',
        label='End date before'
    )
    has_variance = django_filters.BooleanFilter(
        method='filter_has_variance',
        label='Has billing variance'
    )

    class Meta:
        model = BillingRecord
        fields = ['id', 'order_reference', 'invoice_number', 'comments']

    def filter_has_variance(self, queryset, name, value):
        """Filter records with or without billing variance"""
        if value:
            return queryset.exclude(variance=0).exclude(variance__isnull=True)
        else:
            return queryset.filter(Q(variance=0) | Q(variance__isnull=True))

    def search(self, queryset, name, value):
        """Search across multiple fields"""
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(order_reference__icontains=value) |
            Q(invoice_number__icontains=value) |
            Q(comments__icontains=value)
        )


class AuditEventFilterSet(NetBoxModelFilterSet):
    """FilterSet for AuditEvent model"""

    crossconnect_id = django_filters.ModelMultipleChoiceFilter(
        field_name='crossconnect',
        queryset=CrossConnect.objects.all(),
        label='Cross-Connect'
    )
    user_id = django_filters.ModelMultipleChoiceFilter(
        field_name='user',
        queryset=lambda request: __import__('users.models', fromlist=['User']).User.objects.all(),
        label='User'
    )
    field_changed = django_filters.CharFilter(
        lookup_expr='icontains',
        label='Field changed (contains)'
    )
    timestamp = django_filters.DateTimeFilter()
    timestamp__gte = django_filters.DateTimeFilter(
        field_name='timestamp',
        lookup_expr='gte',
        label='After'
    )
    timestamp__lte = django_filters.DateTimeFilter(
        field_name='timestamp',
        lookup_expr='lte',
        label='Before'
    )

    class Meta:
        model = AuditEvent
        fields = ['id', 'field_changed', 'reason', 'comments']

    def search(self, queryset, name, value):
        """Search across multiple fields"""
        if not value.strip():
            return queryset
        return queryset.filter(
            Q(field_changed__icontains=value) |
            Q(old_value__icontains=value) |
            Q(new_value__icontains=value) |
            Q(reason__icontains=value) |
            Q(comments__icontains=value)
        )

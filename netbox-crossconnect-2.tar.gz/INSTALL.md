# Guide d'Installation Détaillé - NetBox Cross-Connect Plugin

## Vue d'ensemble

Ce guide vous accompagne pas à pas pour installer le plugin netbox-crossconnect sur votre instance NetBox.

## Prérequis

Avant de commencer, assurez-vous d'avoir :

- ✅ NetBox version 4.0.0 ou supérieure (testé sur v4.5.6)
- ✅ Accès SSH au serveur NetBox
- ✅ Privilèges sudo/root
- ✅ Python 3.10 ou supérieur
- ✅ NetBox fonctionnel et accessible

## Installation Rapide (5 minutes)

```bash
# 1. Se connecter au serveur
ssh user@your-netbox-server

# 2. Activer l'environnement virtuel NetBox
cd /opt/netbox
source venv/bin/activate

# 3. Installer le plugin
cd /path/to/netbox-crossconnect
pip install .

# 4. Éditer la configuration
sudo nano /opt/netbox/netbox/netbox/configuration.py
# Ajouter 'netbox_crossconnect' dans PLUGINS = [...]

# 5. Exécuter les migrations
cd /opt/netbox/netbox
python manage.py migrate netbox_crossconnect
python manage.py collectstatic --no-input

# 6. Redémarrer NetBox
sudo systemctl restart netbox netbox-rq
```

## Installation Détaillée

### Étape 1 : Télécharger le Plugin

Plusieurs méthodes sont disponibles :

#### Option A : Téléchargement via Git

```bash
cd /opt/netbox
source venv/bin/activate
git clone https://github.com/yourusername/netbox-crossconnect.git
cd netbox-crossconnect
```

#### Option B : Téléchargement ZIP

1. Télécharger le fichier ZIP du plugin
2. Transférer sur le serveur via SCP :

```bash
# Depuis votre machine locale
scp netbox-crossconnect.zip user@netbox-server:/tmp/

# Sur le serveur NetBox
cd /opt/netbox
unzip /tmp/netbox-crossconnect.zip
cd netbox-crossconnect
```

#### Option C : Copie manuelle

```bash
# Copier le dossier netbox_crossconnect directement
scp -r netbox_crossconnect user@netbox-server:/tmp/

# Sur le serveur
sudo mv /tmp/netbox_crossconnect /opt/netbox/netbox/netbox/plugins/
sudo chown -R netbox:netbox /opt/netbox/netbox/netbox/plugins/netbox_crossconnect
```

### Étape 2 : Installer le Package Python

```bash
# Activer l'environnement virtuel
cd /opt/netbox
source venv/bin/activate

# Vérifier que vous êtes dans le bon environnement
which python
# Doit retourner : /opt/netbox/venv/bin/python

# Installer le plugin
cd netbox-crossconnect
pip install .

# Vérifier l'installation
pip show netbox-crossconnect
pip list | grep netbox
```

### Étape 3 : Configuration NetBox

#### 3.1 Éditer configuration.py

```bash
sudo nano /opt/netbox/netbox/netbox/configuration.py
```

#### 3.2 Ajouter le plugin

Chercher la section `PLUGINS` et ajouter :

```python
PLUGINS = [
    'netbox_crossconnect',
    # Autres plugins existants...
]
```

#### 3.3 Configuration optionnelle

Ajouter juste après la section PLUGINS :

```python
PLUGINS_CONFIG = {
    'netbox_crossconnect': {
        # Activer le module de facturation
        'enable_billing': True,

        # Activer le module d'ordres de travail
        'enable_work_orders': True,
    }
}
```

#### 3.4 Sauvegarder

Appuyer sur `Ctrl+X`, puis `Y`, puis `Entrée`.

### Étape 4 : Migrations de Base de Données

```bash
cd /opt/netbox/netbox

# Vérifier les migrations disponibles
python manage.py showmigrations netbox_crossconnect

# Exécuter les migrations
python manage.py migrate netbox_crossconnect

# Vérifier que tout est bien migré
python manage.py showmigrations netbox_crossconnect
```

Résultat attendu :
```
netbox_crossconnect
 [X] 0001_initial
```

### Étape 5 : Collecter les Fichiers Statiques

```bash
python manage.py collectstatic --no-input
```

### Étape 6 : Redémarrer les Services

#### Pour systemd (installation standard)

```bash
# Redémarrer les services
sudo systemctl restart netbox
sudo systemctl restart netbox-rq

# Vérifier le statut
sudo systemctl status netbox
sudo systemctl status netbox-rq

# Voir les logs si erreur
sudo journalctl -u netbox -n 50
sudo journalctl -u netbox-rq -n 50
```

#### Pour supervisord

```bash
sudo supervisorctl restart netbox
sudo supervisorctl restart netbox-rq
sudo supervisorctl status
```

#### Pour Gunicorn/uWSGI manuel

```bash
sudo systemctl restart netbox
# ou
sudo /opt/netbox/restart.sh
```

### Étape 7 : Vérification

#### 7.1 Interface Web

1. Ouvrir NetBox dans votre navigateur : `https://your-netbox-server/`
2. Se connecter avec vos identifiants administrateur
3. Vérifier qu'un nouveau menu **"Cross-Connects"** apparaît dans la barre de navigation
4. Cliquer sur "Cross-Connects" → "Cross-Connects"
5. Vous devriez voir une page vide avec le bouton "+ Add"

#### 7.2 API REST

Tester l'API :

```bash
curl -H "Authorization: Token YOUR_API_TOKEN" \
     -H "Accept: application/json" \
     https://your-netbox-server/api/plugins/crossconnect/crossconnects/
```

Résultat attendu : `{"count":0,"next":null,"previous":null,"results":[]}`

#### 7.3 Ligne de commande

```bash
cd /opt/netbox/netbox
python manage.py shell

# Dans le shell Python :
from netbox_crossconnect.models import CrossConnect
print(CrossConnect.objects.count())
# Doit retourner : 0

exit()
```

## Permissions Utilisateurs

### Attribuer les permissions

1. Aller dans **Admin** → **Groups** (ou Users)
2. Sélectionner un groupe/utilisateur
3. Dans la section **Object permissions**, ajouter :
   - `netbox_crossconnect | cross-connect | Can view cross-connect`
   - `netbox_crossconnect | cross-connect | Can add cross-connect`
   - `netbox_crossconnect | cross-connect | Can change cross-connect`
   - `netbox_crossconnect | cross-connect | Can delete cross-connect`
4. Répéter pour les autres modèles (endpoint, work order, etc.)

## Tests de Base

### Créer un cross-connect de test

```bash
cd /opt/netbox/netbox
python manage.py shell
```

```python
from netbox_crossconnect.models import CrossConnect
from dcim.models import Site

# Créer un site de test si nécessaire
site, _ = Site.objects.get_or_create(
    name='Test Site',
    slug='test-site'
)

# Créer un cross-connect
xc = CrossConnect.objects.create(
    reference='XC-TEST-001',
    site=site,
    type='fiber-sm',
    capacity='10g',
    status='requested'
)

print(f"Cross-connect créé : {xc}")
exit()
```

Vérifier dans l'interface web que le cross-connect apparaît.

## Dépannage

### Problème : Le menu n'apparaît pas

**Solution :**
```bash
# Vérifier la configuration
cat /opt/netbox/netbox/netbox/configuration.py | grep netbox_crossconnect

# Vérifier les logs
sudo journalctl -u netbox -n 100

# Redémarrer complètement
sudo systemctl restart netbox netbox-rq
```

### Problème : Erreur "No module named netbox_crossconnect"

**Solution :**
```bash
# Vérifier l'installation
source /opt/netbox/venv/bin/activate
pip show netbox-crossconnect

# Réinstaller si nécessaire
cd /path/to/netbox-crossconnect
pip install --force-reinstall .
```

### Problème : Erreur de migration

**Solution :**
```bash
cd /opt/netbox/netbox

# Voir les migrations en attente
python manage.py showmigrations

# Exécuter à nouveau
python manage.py migrate netbox_crossconnect

# Si toujours erreur, voir les détails
python manage.py migrate netbox_crossconnect --verbosity 2
```

### Problème : Erreur 500 après installation

**Solution :**
```bash
# Activer le mode DEBUG temporairement
sudo nano /opt/netbox/netbox/netbox/configuration.py
# Mettre DEBUG = True

# Redémarrer et voir l'erreur détaillée dans le navigateur
sudo systemctl restart netbox

# NE PAS OUBLIER de remettre DEBUG = False après !
```

### Problème : Permissions denied

**Solution :**
```bash
# Corriger les permissions
sudo chown -R netbox:netbox /opt/netbox
sudo chmod -R 755 /opt/netbox
```

## Mise à Jour du Plugin

```bash
cd /opt/netbox
source venv/bin/activate

# Méthode Git
cd netbox-crossconnect
git pull
pip install --upgrade .

# Ou méthode manuelle
cd /path/to/new/version
pip install --upgrade .

# Exécuter les nouvelles migrations
cd /opt/netbox/netbox
python manage.py migrate netbox_crossconnect
python manage.py collectstatic --no-input

# Redémarrer
sudo systemctl restart netbox netbox-rq
```

## Désinstallation

### Désinstallation Complète (avec suppression des données)

```bash
# 1. Retirer de la configuration
sudo nano /opt/netbox/netbox/netbox/configuration.py
# Supprimer 'netbox_crossconnect' de PLUGINS

# 2. Annuler les migrations (ATTENTION : supprime les données !)
cd /opt/netbox/netbox
source /opt/netbox/venv/bin/activate
python manage.py migrate netbox_crossconnect zero

# 3. Désinstaller le package
pip uninstall netbox-crossconnect

# 4. Redémarrer
sudo systemctl restart netbox netbox-rq
```

### Désinstallation Partielle (garde les données)

```bash
# 1. Retirer seulement de la configuration
sudo nano /opt/netbox/netbox/netbox/configuration.py
# Supprimer 'netbox_crossconnect' de PLUGINS

# 2. Redémarrer
sudo systemctl restart netbox netbox-rq

# Les données restent en base, vous pouvez réactiver plus tard
```

## Support

- Documentation : Voir README.md
- Issues : https://github.com/yourusername/netbox-crossconnect/issues
- NetBox Community : https://github.com/netbox-community/netbox/discussions

## Checklist d'Installation

- [ ] NetBox 4.0+ installé et fonctionnel
- [ ] Plugin téléchargé sur le serveur
- [ ] Package installé via pip
- [ ] Configuration.py modifié
- [ ] Migrations exécutées avec succès
- [ ] Fichiers statiques collectés
- [ ] Services redémarrés
- [ ] Menu visible dans l'interface
- [ ] API accessible
- [ ] Permissions configurées
- [ ] Test de création effectué

from django.contrib import admin
from .models import CrossConnect, CrossConnectEndpoint, WorkOrder, BillingRecord, AuditEvent


@admin.register(CrossConnect)
class CrossConnectAdmin(admin.ModelAdmin):
    list_display = ['reference', 'tenant', 'provider', 'site', 'status', 'type', 'capacity']
    list_filter = ['status', 'type', 'capacity', 'site']
    search_fields = ['reference', 'comments']
    autocomplete_fields = ['tenant', 'provider', 'site', 'location']


@admin.register(CrossConnectEndpoint)
class CrossConnectEndpointAdmin(admin.ModelAdmin):
    list_display = ['crossconnect', 'side', 'endpoint_type', 'rack', 'port_label']
    list_filter = ['side', 'endpoint_type']
    search_fields = ['port_label', 'patch_label']
    autocomplete_fields = ['crossconnect', 'rack']


@admin.register(WorkOrder)
class WorkOrderAdmin(admin.ModelAdmin):
    list_display = ['order_number', 'crossconnect', 'action', 'scheduled_date', 'completed_date', 'is_validated']
    list_filter = ['action', 'is_validated']
    search_fields = ['order_number', 'technician']
    autocomplete_fields = ['crossconnect']


@admin.register(BillingRecord)
class BillingRecordAdmin(admin.ModelAdmin):
    list_display = ['crossconnect', 'provider', 'billing_start_date', 'monthly_charge', 'variance']
    list_filter = ['provider']
    search_fields = ['order_reference', 'invoice_number']
    autocomplete_fields = ['crossconnect', 'provider']


@admin.register(AuditEvent)
class AuditEventAdmin(admin.ModelAdmin):
    list_display = ['crossconnect', 'user', 'timestamp', 'field_changed']
    list_filter = ['timestamp']
    search_fields = ['field_changed', 'reason']
    autocomplete_fields = ['crossconnect', 'user']
    readonly_fields = ['timestamp']

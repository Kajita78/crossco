import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models
import utilities.json


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('tenancy', '0001_initial'),
        ('circuits', '0001_initial'),
        ('dcim', '0001_initial'),
        ('contenttypes', '0002_remove_content_type_name'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='CrossConnect',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('created', models.DateTimeField(auto_now_add=True, null=True)),
                ('last_updated', models.DateTimeField(auto_now=True, null=True)),
                ('custom_field_data', models.JSONField(blank=True, default=dict, encoder=utilities.json.CustomFieldJSONEncoder)),
                ('reference', models.CharField(help_text='Unique reference for this cross-connect', max_length=100, unique=True)),
                ('type', models.CharField(help_text='Cable type', max_length=50)),
                ('capacity', models.CharField(help_text='Bandwidth capacity', max_length=50)),
                ('status', models.CharField(default='requested', help_text='Current status', max_length=50)),
                ('order_date', models.DateField(blank=True, help_text='Date when ordered', null=True)),
                ('delivery_date', models.DateField(blank=True, help_text='Expected or actual delivery date', null=True)),
                ('monthly_cost', models.DecimalField(blank=True, decimal_places=2, help_text='Monthly recurring charge (MRC)', max_digits=10, null=True)),
                ('one_time_cost', models.DecimalField(blank=True, decimal_places=2, help_text='One-time installation charge (NRC)', max_digits=10, null=True)),
                ('comments', models.TextField(blank=True, help_text='Additional notes')),
                ('location', models.ForeignKey(blank=True, help_text='Room/MMR within the site', null=True, on_delete=django.db.models.deletion.PROTECT, related_name='crossconnects', to='dcim.location')),
                ('provider', models.ForeignKey(blank=True, help_text='Service provider/Operator', null=True, on_delete=django.db.models.deletion.PROTECT, related_name='crossconnects', to='circuits.provider')),
                ('site', models.ForeignKey(help_text='Datacenter site', on_delete=django.db.models.deletion.PROTECT, related_name='crossconnects', to='dcim.site')),
                ('tenant', models.ForeignKey(blank=True, help_text='Customer/Tenant', null=True, on_delete=django.db.models.deletion.PROTECT, related_name='crossconnects', to='tenancy.tenant')),
            ],
            options={
                'verbose_name': 'Cross-Connect',
                'verbose_name_plural': 'Cross-Connects',
                'ordering': ['reference'],
            },
        ),
        migrations.CreateModel(
            name='WorkOrder',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('created', models.DateTimeField(auto_now_add=True, null=True)),
                ('last_updated', models.DateTimeField(auto_now=True, null=True)),
                ('custom_field_data', models.JSONField(blank=True, default=dict, encoder=utilities.json.CustomFieldJSONEncoder)),
                ('order_number', models.CharField(help_text='Work order or ticket number', max_length=100, unique=True)),
                ('technician', models.CharField(blank=True, help_text='Technician name or ID', max_length=200)),
                ('action', models.CharField(help_text='Type of action performed', max_length=50)),
                ('scheduled_date', models.DateTimeField(blank=True, help_text='Scheduled intervention date', null=True)),
                ('completed_date', models.DateTimeField(blank=True, help_text='Actual completion date', null=True)),
                ('before_state', models.TextField(blank=True, help_text='State before intervention')),
                ('after_state', models.TextField(blank=True, help_text='State after intervention')),
                ('is_validated', models.BooleanField(default=False, help_text='Has been validated by supervisor')),
                ('photo_url', models.URLField(blank=True, help_text='Link to proof photo or documentation')),
                ('comments', models.TextField(blank=True)),
                ('crossconnect', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='work_orders', to='netbox_crossconnect.crossconnect')),
            ],
            options={
                'verbose_name': 'Work Order',
                'verbose_name_plural': 'Work Orders',
                'ordering': ['-completed_date', '-scheduled_date'],
            },
        ),
        migrations.CreateModel(
            name='CrossConnectEndpoint',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('created', models.DateTimeField(auto_now_add=True, null=True)),
                ('last_updated', models.DateTimeField(auto_now=True, null=True)),
                ('custom_field_data', models.JSONField(blank=True, default=dict, encoder=utilities.json.CustomFieldJSONEncoder)),
                ('side', models.CharField(help_text='Side A or B', max_length=10)),
                ('endpoint_type', models.CharField(help_text='Type of endpoint', max_length=50)),
                ('assigned_object_id', models.PositiveBigIntegerField(blank=True, null=True)),
                ('rack_position', models.CharField(blank=True, help_text='Position in rack (U or panel position)', max_length=50)),
                ('port_label', models.CharField(blank=True, help_text='Port or connector label', max_length=100)),
                ('patch_label', models.CharField(blank=True, help_text='Patch cable identification', max_length=100)),
                ('cable_length', models.DecimalField(blank=True, decimal_places=2, help_text='Cable length in meters', max_digits=6, null=True)),
                ('cable_color', models.CharField(blank=True, help_text='Cable color', max_length=50)),
                ('polarity', models.CharField(blank=True, help_text='Fiber polarity or pinout', max_length=50)),
                ('comments', models.TextField(blank=True)),
                ('assigned_object_type', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name='+', to='contenttypes.contenttype')),
                ('crossconnect', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='endpoints', to='netbox_crossconnect.crossconnect')),
                ('rack', models.ForeignKey(blank=True, help_text='Rack location', null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='crossconnect_endpoints', to='dcim.rack')),
            ],
            options={
                'verbose_name': 'Cross-Connect Endpoint',
                'verbose_name_plural': 'Cross-Connect Endpoints',
                'ordering': ['crossconnect', 'side'],
                'unique_together': {('crossconnect', 'side')},
            },
        ),
        migrations.CreateModel(
            name='BillingRecord',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('created', models.DateTimeField(auto_now_add=True, null=True)),
                ('last_updated', models.DateTimeField(auto_now=True, null=True)),
                ('custom_field_data', models.JSONField(blank=True, default=dict, encoder=utilities.json.CustomFieldJSONEncoder)),
                ('order_reference', models.CharField(blank=True, help_text='Provider order reference', max_length=100)),
                ('monthly_charge', models.DecimalField(blank=True, decimal_places=2, help_text='Monthly recurring charge (MRC)', max_digits=10, null=True)),
                ('one_time_charge', models.DecimalField(blank=True, decimal_places=2, help_text='One-time charge (NRC)', max_digits=10, null=True)),
                ('billing_start_date', models.DateField(blank=True, help_text='Billing start date', null=True)),
                ('billing_end_date', models.DateField(blank=True, help_text='Billing end date', null=True)),
                ('expected_charge', models.DecimalField(blank=True, decimal_places=2, help_text='Expected monthly charge', max_digits=10, null=True)),
                ('actual_charge', models.DecimalField(blank=True, decimal_places=2, help_text='Actual billed amount', max_digits=10, null=True)),
                ('variance', models.DecimalField(blank=True, decimal_places=2, editable=False, help_text='Difference between expected and actual', max_digits=10, null=True)),
                ('invoice_number', models.CharField(blank=True, help_text='Invoice reference', max_length=100)),
                ('comments', models.TextField(blank=True)),
                ('crossconnect', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='billing_records', to='netbox_crossconnect.crossconnect')),
                ('provider', models.ForeignKey(blank=True, help_text='Billing provider', null=True, on_delete=django.db.models.deletion.PROTECT, related_name='billing_records', to='circuits.provider')),
            ],
            options={
                'verbose_name': 'Billing Record',
                'verbose_name_plural': 'Billing Records',
                'ordering': ['-billing_start_date'],
            },
        ),
        migrations.CreateModel(
            name='AuditEvent',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('created', models.DateTimeField(auto_now_add=True, null=True)),
                ('last_updated', models.DateTimeField(auto_now=True, null=True)),
                ('custom_field_data', models.JSONField(blank=True, default=dict, encoder=utilities.json.CustomFieldJSONEncoder)),
                ('timestamp', models.DateTimeField(auto_now_add=True, help_text='When the change occurred')),
                ('field_changed', models.CharField(blank=True, help_text='Field or aspect that changed', max_length=100)),
                ('old_value', models.TextField(blank=True, help_text='Previous value')),
                ('new_value', models.TextField(blank=True, help_text='New value')),
                ('reason', models.TextField(blank=True, help_text='Reason for change')),
                ('comments', models.TextField(blank=True)),
                ('crossconnect', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='audit_events', to='netbox_crossconnect.crossconnect')),
                ('user', models.ForeignKey(blank=True, help_text='User who made the change', null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='crossconnect_audit_events', to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'Audit Event',
                'verbose_name_plural': 'Audit Events',
                'ordering': ['-timestamp'],
            },
        ),
    ]

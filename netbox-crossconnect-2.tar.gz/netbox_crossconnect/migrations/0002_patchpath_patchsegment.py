from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('netbox_crossconnect', '0001_initial'),
        ('dcim', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='PatchPath',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('created', models.DateTimeField(auto_now_add=True, null=True)),
                ('last_updated', models.DateTimeField(auto_now=True, null=True)),
                ('custom_field_data', models.JSONField(blank=True, default=dict)),
                ('reference', models.CharField(help_text='Unique reference for this patch path', max_length=100, unique=True)),
                ('path_type', models.CharField(choices=[('direct', 'Direct'), ('inter-room', 'Inter-Room'), ('backbone', 'Backbone'), ('mmr', 'MMR/Meet-Me-Room')], default='direct', help_text='Type of patch path', max_length=50)),
                ('total_length', models.DecimalField(blank=True, decimal_places=2, help_text='Total path length in meters', max_digits=8, null=True)),
                ('is_active', models.BooleanField(default=True, help_text='Is this path currently active')),
                ('comments', models.TextField(blank=True)),
                ('crossconnect', models.ForeignKey(blank=True, help_text='Related cross-connect', null=True, on_delete=django.db.models.deletion.CASCADE, related_name='patch_paths', to='netbox_crossconnect.crossconnect')),
                ('destination_location', models.ForeignKey(help_text='Destination room/location', on_delete=django.db.models.deletion.PROTECT, related_name='destination_patch_paths', to='dcim.location')),
                ('source_location', models.ForeignKey(help_text='Source room/location', on_delete=django.db.models.deletion.PROTECT, related_name='source_patch_paths', to='dcim.location')),
            ],
            options={
                'verbose_name': 'Patch Path',
                'verbose_name_plural': 'Patch Paths',
                'ordering': ['reference'],
            },
        ),
        migrations.CreateModel(
            name='PatchSegment',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ('created', models.DateTimeField(auto_now_add=True, null=True)),
                ('last_updated', models.DateTimeField(auto_now=True, null=True)),
                ('custom_field_data', models.JSONField(blank=True, default=dict)),
                ('sequence', models.PositiveIntegerField(help_text='Order in the path (1, 2, 3...)')),
                ('from_panel', models.CharField(blank=True, help_text='Source patch panel', max_length=100)),
                ('from_port', models.CharField(blank=True, help_text='Source port', max_length=100)),
                ('to_panel', models.CharField(blank=True, help_text='Destination patch panel', max_length=100)),
                ('to_port', models.CharField(blank=True, help_text='Destination port', max_length=100)),
                ('cable_type', models.CharField(choices=[('copper', 'Copper'), ('fiber-sm', 'Fiber Single-Mode'), ('fiber-mm', 'Fiber Multi-Mode')], help_text='Cable type for this segment', max_length=50)),
                ('cable_length', models.DecimalField(blank=True, decimal_places=2, help_text='Segment cable length in meters', max_digits=6, null=True)),
                ('cable_color', models.CharField(blank=True, help_text='Cable color', max_length=50)),
                ('cable_label', models.CharField(blank=True, help_text='Cable identification label', max_length=100)),
                ('comments', models.TextField(blank=True)),
                ('from_location', models.ForeignKey(help_text='Source location/room', on_delete=django.db.models.deletion.PROTECT, related_name='segment_sources', to='dcim.location')),
                ('from_rack', models.ForeignKey(blank=True, help_text='Source rack', null=True, on_delete=django.db.models.deletion.PROTECT, related_name='segment_sources', to='dcim.rack')),
                ('patch_path', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='segments', to='netbox_crossconnect.patchpath')),
                ('to_location', models.ForeignKey(help_text='Destination location/room', on_delete=django.db.models.deletion.PROTECT, related_name='segment_destinations', to='dcim.location')),
                ('to_rack', models.ForeignKey(blank=True, help_text='Destination rack', null=True, on_delete=django.db.models.deletion.PROTECT, related_name='segment_destinations', to='dcim.rack')),
            ],
            options={
                'verbose_name': 'Patch Segment',
                'verbose_name_plural': 'Patch Segments',
                'ordering': ['patch_path', 'sequence'],
                'unique_together': {('patch_path', 'sequence')},
            },
        ),
    ]

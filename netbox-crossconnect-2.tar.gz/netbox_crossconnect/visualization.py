from django.db.models import Q
from .models import PatchPath, PatchSegment, CrossConnect


def generate_path_trace_data(patch_path):
    """
    Generate data structure for visual path tracing.
    Returns nodes and edges for graph visualization.
    """
    nodes = []
    edges = []

    segments = patch_path.segments.order_by('sequence')

    for idx, segment in enumerate(segments):
        source_node = {
            'id': f'node_{patch_path.id}_{idx}_source',
            'label': f'{segment.from_location.name}\n{segment.from_panel or "N/A"}\n{segment.from_port or ""}',
            'location': segment.from_location.name,
            'rack': segment.from_rack.name if segment.from_rack else 'N/A',
            'panel': segment.from_panel or 'N/A',
            'port': segment.from_port or '',
            'type': 'endpoint' if idx == 0 else 'intermediate'
        }

        dest_node = {
            'id': f'node_{patch_path.id}_{idx}_dest',
            'label': f'{segment.to_location.name}\n{segment.to_panel or "N/A"}\n{segment.to_port or ""}',
            'location': segment.to_location.name,
            'rack': segment.to_rack.name if segment.to_rack else 'N/A',
            'panel': segment.to_panel or 'N/A',
            'port': segment.to_port or '',
            'type': 'endpoint' if idx == len(segments) - 1 else 'intermediate'
        }

        if idx == 0:
            nodes.append(source_node)

        nodes.append(dest_node)

        edge = {
            'id': f'edge_{patch_path.id}_{idx}',
            'source': source_node['id'],
            'target': dest_node['id'],
            'label': f'{segment.cable_type}\n{segment.cable_length}m' if segment.cable_length else segment.cable_type,
            'cable_type': segment.cable_type,
            'cable_length': float(segment.cable_length) if segment.cable_length else 0,
            'cable_color': segment.cable_color or 'gray',
            'cable_label': segment.cable_label or '',
            'sequence': segment.sequence
        }

        edges.append(edge)

    return {
        'nodes': nodes,
        'edges': edges,
        'path_info': {
            'reference': patch_path.reference,
            'type': patch_path.path_type,
            'total_length': float(patch_path.total_length) if patch_path.total_length else 0,
            'is_active': patch_path.is_active,
            'source': patch_path.source_location.name,
            'destination': patch_path.destination_location.name
        }
    }


def find_inter_room_paths(location_a, location_b):
    """
    Find all patch paths between two locations.
    """
    paths = PatchPath.objects.filter(
        Q(source_location=location_a, destination_location=location_b) |
        Q(source_location=location_b, destination_location=location_a)
    ).prefetch_related('segments')

    return paths


def generate_network_topology(site=None, location=None):
    """
    Generate complete network topology for visualization.
    Shows all cross-connects and their interconnections.
    """
    query = PatchPath.objects.all()

    if location:
        query = query.filter(
            Q(source_location=location) | Q(destination_location=location)
        )
    elif site:
        query = query.filter(source_location__site=site)

    query = query.prefetch_related('segments', 'crossconnect')

    all_nodes = {}
    all_edges = []

    for path in query:
        path_data = generate_path_trace_data(path)

        for node in path_data['nodes']:
            node_key = f"{node['location']}_{node['rack']}_{node['panel']}_{node['port']}"
            if node_key not in all_nodes:
                all_nodes[node_key] = node

        for edge in path_data['edges']:
            all_edges.append(edge)

    return {
        'nodes': list(all_nodes.values()),
        'edges': all_edges,
        'metadata': {
            'total_paths': query.count(),
            'location': location.name if location else 'All',
            'site': site.name if site else 'All'
        }
    }


def generate_mmr_connections(location):
    """
    Generate visualization data for MMR (Meet-Me Room) connections.
    Shows all paths passing through a specific MMR location.
    """
    mmr_paths = PatchPath.objects.filter(
        path_type='mmr'
    ).filter(
        Q(source_location=location) |
        Q(destination_location=location) |
        Q(segments__from_location=location) |
        Q(segments__to_location=location)
    ).distinct().prefetch_related('segments')

    topology_data = {
        'mmr_location': location.name,
        'paths': [],
        'total_connections': mmr_paths.count()
    }

    for path in mmr_paths:
        path_trace = generate_path_trace_data(path)
        topology_data['paths'].append(path_trace)

    return topology_data


def calculate_path_metrics(patch_path):
    """
    Calculate various metrics for a patch path.
    """
    segments = patch_path.segments.all()

    metrics = {
        'total_segments': segments.count(),
        'total_length': 0,
        'locations_crossed': set(),
        'racks_used': set(),
        'cable_types': set(),
        'average_segment_length': 0
    }

    lengths = []

    for segment in segments:
        if segment.cable_length:
            metrics['total_length'] += float(segment.cable_length)
            lengths.append(float(segment.cable_length))

        metrics['locations_crossed'].add(segment.from_location.name)
        metrics['locations_crossed'].add(segment.to_location.name)

        if segment.from_rack:
            metrics['racks_used'].add(segment.from_rack.name)
        if segment.to_rack:
            metrics['racks_used'].add(segment.to_rack.name)

        metrics['cable_types'].add(segment.cable_type)

    if lengths:
        metrics['average_segment_length'] = sum(lengths) / len(lengths)

    metrics['locations_crossed'] = list(metrics['locations_crossed'])
    metrics['racks_used'] = list(metrics['racks_used'])
    metrics['cable_types'] = list(metrics['cable_types'])

    return metrics

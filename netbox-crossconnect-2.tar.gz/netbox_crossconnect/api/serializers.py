from rest_framework import serializers
from netbox.api.serializers import NetBoxModelSerializer
from netbox.api.fields import RelatedObjectCountField

from netbox_crossconnect.models import (
    CrossConnect, CrossConnectEndpoint, WorkOrder, BillingRecord, AuditEvent,
    PatchPath, PatchSegment
)


class CrossConnectSerializer(NetBoxModelSerializer):
    """REST API serializer for CrossConnect model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:crossconnect-detail'
    )
    tenant = serializers.SerializerMethodField()
    provider = serializers.SerializerMethodField()
    site = serializers.SerializerMethodField()
    location = serializers.SerializerMethodField()
    endpoint_count = RelatedObjectCountField('endpoints')
    work_order_count = RelatedObjectCountField('work_orders')
    billing_record_count = RelatedObjectCountField('billing_records')

    class Meta:
        model = CrossConnect
        fields = [
            'id', 'url', 'display', 'reference', 'tenant', 'provider', 'site',
            'location', 'type', 'capacity', 'status', 'order_date',
            'delivery_date', 'monthly_cost', 'one_time_cost', 'comments',
            'endpoint_count', 'work_order_count', 'billing_record_count',
            'tags', 'custom_fields', 'created', 'last_updated'
        ]

    def get_tenant(self, obj):
        if obj.tenant:
            return {
                'id': obj.tenant.id,
                'name': obj.tenant.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/tenancy/tenants/{obj.tenant.id}/'
                )
            }
        return None

    def get_provider(self, obj):
        if obj.provider:
            return {
                'id': obj.provider.id,
                'name': obj.provider.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/circuits/providers/{obj.provider.id}/'
                )
            }
        return None

    def get_site(self, obj):
        return {
            'id': obj.site.id,
            'name': obj.site.name,
            'url': self.context['request'].build_absolute_uri(
                f'/api/dcim/sites/{obj.site.id}/'
            )
        }

    def get_location(self, obj):
        if obj.location:
            return {
                'id': obj.location.id,
                'name': obj.location.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/dcim/locations/{obj.location.id}/'
                )
            }
        return None


class CrossConnectEndpointSerializer(NetBoxModelSerializer):
    """REST API serializer for CrossConnectEndpoint model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:crossconnectendpoint-detail'
    )
    crossconnect = serializers.SerializerMethodField()
    rack = serializers.SerializerMethodField()

    class Meta:
        model = CrossConnectEndpoint
        fields = [
            'id', 'url', 'display', 'crossconnect', 'side', 'endpoint_type',
            'rack', 'rack_position', 'port_label', 'patch_label', 'cable_length',
            'cable_color', 'polarity', 'comments', 'tags', 'custom_fields',
            'created', 'last_updated'
        ]

    def get_crossconnect(self, obj):
        return {
            'id': obj.crossconnect.id,
            'reference': obj.crossconnect.reference,
            'url': self.context['request'].build_absolute_uri(
                f'/api/plugins/crossconnect/crossconnects/{obj.crossconnect.id}/'
            )
        }

    def get_rack(self, obj):
        if obj.rack:
            return {
                'id': obj.rack.id,
                'name': obj.rack.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/dcim/racks/{obj.rack.id}/'
                )
            }
        return None


class WorkOrderSerializer(NetBoxModelSerializer):
    """REST API serializer for WorkOrder model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:workorder-detail'
    )
    crossconnect = serializers.SerializerMethodField()

    class Meta:
        model = WorkOrder
        fields = [
            'id', 'url', 'display', 'order_number', 'crossconnect', 'technician',
            'action', 'scheduled_date', 'completed_date', 'before_state',
            'after_state', 'is_validated', 'photo_url', 'comments', 'tags',
            'custom_fields', 'created', 'last_updated'
        ]

    def get_crossconnect(self, obj):
        return {
            'id': obj.crossconnect.id,
            'reference': obj.crossconnect.reference,
            'url': self.context['request'].build_absolute_uri(
                f'/api/plugins/crossconnect/crossconnects/{obj.crossconnect.id}/'
            )
        }


class BillingRecordSerializer(NetBoxModelSerializer):
    """REST API serializer for BillingRecord model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:billingrecord-detail'
    )
    crossconnect = serializers.SerializerMethodField()
    provider = serializers.SerializerMethodField()

    class Meta:
        model = BillingRecord
        fields = [
            'id', 'url', 'display', 'crossconnect', 'provider', 'order_reference',
            'monthly_charge', 'one_time_charge', 'billing_start_date',
            'billing_end_date', 'expected_charge', 'actual_charge', 'variance',
            'invoice_number', 'comments', 'tags', 'custom_fields', 'created',
            'last_updated'
        ]

    def get_crossconnect(self, obj):
        return {
            'id': obj.crossconnect.id,
            'reference': obj.crossconnect.reference,
            'url': self.context['request'].build_absolute_uri(
                f'/api/plugins/crossconnect/crossconnects/{obj.crossconnect.id}/'
            )
        }

    def get_provider(self, obj):
        if obj.provider:
            return {
                'id': obj.provider.id,
                'name': obj.provider.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/circuits/providers/{obj.provider.id}/'
                )
            }
        return None


class AuditEventSerializer(NetBoxModelSerializer):
    """REST API serializer for AuditEvent model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:auditevent-detail'
    )
    crossconnect = serializers.SerializerMethodField()
    user = serializers.SerializerMethodField()

    class Meta:
        model = AuditEvent
        fields = [
            'id', 'url', 'display', 'crossconnect', 'user', 'timestamp',
            'field_changed', 'old_value', 'new_value', 'reason', 'comments',
            'tags', 'custom_fields', 'created', 'last_updated'
        ]

    def get_crossconnect(self, obj):
        return {
            'id': obj.crossconnect.id,
            'reference': obj.crossconnect.reference,
            'url': self.context['request'].build_absolute_uri(
                f'/api/plugins/crossconnect/crossconnects/{obj.crossconnect.id}/'
            )
        }

    def get_user(self, obj):
        if obj.user:
            return {
                'id': obj.user.id,
                'username': obj.user.username,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/users/users/{obj.user.id}/'
                )
            }
        return None


class PatchPathSerializer(NetBoxModelSerializer):
    """REST API serializer for PatchPath model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:patchpath-detail'
    )
    crossconnect = serializers.SerializerMethodField()
    source_location = serializers.SerializerMethodField()
    destination_location = serializers.SerializerMethodField()
    segment_count = RelatedObjectCountField('segments')

    class Meta:
        model = PatchPath
        fields = [
            'id', 'url', 'display', 'reference', 'crossconnect', 'path_type',
            'source_location', 'destination_location', 'total_length',
            'is_active', 'segment_count', 'comments', 'tags', 'custom_fields',
            'created', 'last_updated'
        ]

    def get_crossconnect(self, obj):
        if obj.crossconnect:
            return {
                'id': obj.crossconnect.id,
                'reference': obj.crossconnect.reference,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/plugins/crossconnect/crossconnects/{obj.crossconnect.id}/'
                )
            }
        return None

    def get_source_location(self, obj):
        return {
            'id': obj.source_location.id,
            'name': obj.source_location.name,
            'url': self.context['request'].build_absolute_uri(
                f'/api/dcim/locations/{obj.source_location.id}/'
            )
        }

    def get_destination_location(self, obj):
        return {
            'id': obj.destination_location.id,
            'name': obj.destination_location.name,
            'url': self.context['request'].build_absolute_uri(
                f'/api/dcim/locations/{obj.destination_location.id}/'
            )
        }


class PatchSegmentSerializer(NetBoxModelSerializer):
    """REST API serializer for PatchSegment model"""

    url = serializers.HyperlinkedIdentityField(
        view_name='plugins-api:netbox_crossconnect-api:patchsegment-detail'
    )
    patch_path = serializers.SerializerMethodField()
    from_location = serializers.SerializerMethodField()
    to_location = serializers.SerializerMethodField()
    from_rack = serializers.SerializerMethodField()
    to_rack = serializers.SerializerMethodField()

    class Meta:
        model = PatchSegment
        fields = [
            'id', 'url', 'display', 'patch_path', 'sequence', 'from_rack',
            'from_location', 'from_panel', 'from_port', 'to_rack', 'to_location',
            'to_panel', 'to_port', 'cable_type', 'cable_length', 'cable_color',
            'cable_label', 'comments', 'tags', 'custom_fields', 'created',
            'last_updated'
        ]

    def get_patch_path(self, obj):
        return {
            'id': obj.patch_path.id,
            'reference': obj.patch_path.reference,
            'url': self.context['request'].build_absolute_uri(
                f'/api/plugins/crossconnect/patch-paths/{obj.patch_path.id}/'
            )
        }

    def get_from_location(self, obj):
        return {
            'id': obj.from_location.id,
            'name': obj.from_location.name,
            'url': self.context['request'].build_absolute_uri(
                f'/api/dcim/locations/{obj.from_location.id}/'
            )
        }

    def get_to_location(self, obj):
        return {
            'id': obj.to_location.id,
            'name': obj.to_location.name,
            'url': self.context['request'].build_absolute_uri(
                f'/api/dcim/locations/{obj.to_location.id}/'
            )
        }

    def get_from_rack(self, obj):
        if obj.from_rack:
            return {
                'id': obj.from_rack.id,
                'name': obj.from_rack.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/dcim/racks/{obj.from_rack.id}/'
                )
            }
        return None

    def get_to_rack(self, obj):
        if obj.to_rack:
            return {
                'id': obj.to_rack.id,
                'name': obj.to_rack.name,
                'url': self.context['request'].build_absolute_uri(
                    f'/api/dcim/racks/{obj.to_rack.id}/'
                )
            }
        return None

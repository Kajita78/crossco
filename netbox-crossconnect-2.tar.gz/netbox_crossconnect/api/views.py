from netbox.api.viewsets import NetBoxModelViewSet

from netbox_crossconnect.models import (
    CrossConnect, CrossConnectEndpoint, WorkOrder, BillingRecord, AuditEvent,
    PatchPath, PatchSegment
)
from netbox_crossconnect.filtersets import (
    CrossConnectFilterSet, CrossConnectEndpointFilterSet, WorkOrderFilterSet,
    BillingRecordFilterSet, AuditEventFilterSet, PatchPathFilterSet, PatchSegmentFilterSet
)
from .serializers import (
    CrossConnectSerializer, CrossConnectEndpointSerializer, WorkOrderSerializer,
    BillingRecordSerializer, AuditEventSerializer, PatchPathSerializer, PatchSegmentSerializer
)


class CrossConnectViewSet(NetBoxModelViewSet):
    """REST API viewset for CrossConnect model"""
    queryset = CrossConnect.objects.prefetch_related(
        'tenant', 'provider', 'site', 'location', 'endpoints', 'tags'
    )
    serializer_class = CrossConnectSerializer
    filterset_class = CrossConnectFilterSet


class CrossConnectEndpointViewSet(NetBoxModelViewSet):
    """REST API viewset for CrossConnectEndpoint model"""
    queryset = CrossConnectEndpoint.objects.prefetch_related(
        'crossconnect', 'rack', 'tags'
    )
    serializer_class = CrossConnectEndpointSerializer
    filterset_class = CrossConnectEndpointFilterSet


class WorkOrderViewSet(NetBoxModelViewSet):
    """REST API viewset for WorkOrder model"""
    queryset = WorkOrder.objects.prefetch_related('crossconnect', 'tags')
    serializer_class = WorkOrderSerializer
    filterset_class = WorkOrderFilterSet


class BillingRecordViewSet(NetBoxModelViewSet):
    """REST API viewset for BillingRecord model"""
    queryset = BillingRecord.objects.prefetch_related(
        'crossconnect', 'provider', 'tags'
    )
    serializer_class = BillingRecordSerializer
    filterset_class = BillingRecordFilterSet


class AuditEventViewSet(NetBoxModelViewSet):
    """REST API viewset for AuditEvent model"""
    queryset = AuditEvent.objects.prefetch_related(
        'crossconnect', 'user', 'tags'
    )
    serializer_class = AuditEventSerializer
    filterset_class = AuditEventFilterSet


class PatchPathViewSet(NetBoxModelViewSet):
    """REST API viewset for PatchPath model"""
    queryset = PatchPath.objects.prefetch_related(
        'crossconnect', 'source_location', 'destination_location', 'segments', 'tags'
    )
    serializer_class = PatchPathSerializer
    filterset_class = PatchPathFilterSet


class PatchSegmentViewSet(NetBoxModelViewSet):
    """REST API viewset for PatchSegment model"""
    queryset = PatchSegment.objects.prefetch_related(
        'patch_path', 'from_location', 'to_location', 'from_rack', 'to_rack', 'tags'
    )
    serializer_class = PatchSegmentSerializer
    filterset_class = PatchSegmentFilterSet

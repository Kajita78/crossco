from django import forms
from netbox.forms import NetBoxModelForm, NetBoxModelFilterSetForm
from utilities.forms.fields import DynamicModelChoiceField, DynamicModelMultipleChoiceField, TagFilterField, CommentField
from utilities.forms.rendering import FieldSet
from dcim.models import Site, Location, Rack, Device, Interface
from circuits.models import Provider, Circuit
from tenancy.models import Tenant

from .models import (
    CrossConnect, CrossConnectEndpoint, WorkOrder, BillingRecord, AuditEvent,
    PatchPath, PatchSegment,
    CrossConnectTypeChoices, CrossConnectCapacityChoices, CrossConnectStatusChoices,
    EndpointSideChoices, EndpointTypeChoices, WorkOrderActionChoices, PatchPathTypeChoices
)


class CrossConnectForm(NetBoxModelForm):
    """Form for creating and editing CrossConnect objects"""

    tenant = DynamicModelChoiceField(
        queryset=Tenant.objects.all(),
        required=False,
        label='Customer/Tenant'
    )
    provider = DynamicModelChoiceField(
        queryset=Provider.objects.all(),
        required=False,
        label='Operator/Provider'
    )
    site = DynamicModelChoiceField(
        queryset=Site.objects.all(),
        required=True
    )
    location = DynamicModelChoiceField(
        queryset=Location.objects.all(),
        required=False,
        query_params={'site_id': '$site'},
        label='Room/MMR'
    )
    comments = CommentField()

    fieldsets = (
        FieldSet('reference', 'tenant', 'provider', name='Basic Information'),
        FieldSet('site', 'location', name='Location'),
        FieldSet('type', 'capacity', 'status', name='Technical Details'),
        FieldSet('order_date', 'delivery_date', name='Dates'),
        FieldSet('monthly_cost', 'one_time_cost', name='Costs'),
        FieldSet('comments', 'tags', name='Additional Information'),
    )

    class Meta:
        model = CrossConnect
        fields = [
            'reference', 'tenant', 'provider', 'site', 'location',
            'type', 'capacity', 'status', 'order_date', 'delivery_date',
            'monthly_cost', 'one_time_cost', 'comments', 'tags'
        ]


class CrossConnectFilterForm(NetBoxModelFilterSetForm):
    """Filter form for CrossConnect list view"""

    model = CrossConnect

    tenant_id = DynamicModelMultipleChoiceField(
        queryset=Tenant.objects.all(),
        required=False,
        label='Customer/Tenant'
    )
    provider_id = DynamicModelMultipleChoiceField(
        queryset=Provider.objects.all(),
        required=False,
        label='Operator/Provider'
    )
    site_id = DynamicModelMultipleChoiceField(
        queryset=Site.objects.all(),
        required=False,
        label='Site'
    )
    location_id = DynamicModelMultipleChoiceField(
        queryset=Location.objects.all(),
        required=False,
        label='Location'
    )
    type = forms.MultipleChoiceField(
        choices=CrossConnectTypeChoices,
        required=False
    )
    capacity = forms.MultipleChoiceField(
        choices=CrossConnectCapacityChoices,
        required=False
    )
    status = forms.MultipleChoiceField(
        choices=CrossConnectStatusChoices,
        required=False
    )
    tag = TagFilterField(model)


class CrossConnectEndpointForm(NetBoxModelForm):
    """Form for creating and editing CrossConnectEndpoint objects"""

    crossconnect = DynamicModelChoiceField(
        queryset=CrossConnect.objects.all(),
        required=True
    )
    rack = DynamicModelChoiceField(
        queryset=Rack.objects.all(),
        required=False
    )
    comments = CommentField()

    fieldsets = (
        FieldSet('crossconnect', 'side', 'endpoint_type', name='Basic Information'),
        FieldSet('rack', 'rack_position', 'port_label', 'patch_label', name='Physical Location'),
        FieldSet('cable_length', 'cable_color', 'polarity', name='Cable Details'),
        FieldSet('comments', 'tags', name='Additional Information'),
    )

    class Meta:
        model = CrossConnectEndpoint
        fields = [
            'crossconnect', 'side', 'endpoint_type', 'rack', 'rack_position',
            'port_label', 'patch_label', 'cable_length', 'cable_color',
            'polarity', 'comments', 'tags'
        ]


class CrossConnectEndpointFilterForm(NetBoxModelFilterSetForm):
    """Filter form for CrossConnectEndpoint list view"""

    model = CrossConnectEndpoint

    crossconnect_id = DynamicModelMultipleChoiceField(
        queryset=CrossConnect.objects.all(),
        required=False,
        label='Cross-Connect'
    )
    side = forms.MultipleChoiceField(
        choices=EndpointSideChoices,
        required=False
    )
    endpoint_type = forms.MultipleChoiceField(
        choices=EndpointTypeChoices,
        required=False
    )
    rack_id = DynamicModelMultipleChoiceField(
        queryset=Rack.objects.all(),
        required=False,
        label='Rack'
    )
    tag = TagFilterField(model)


class WorkOrderForm(NetBoxModelForm):
    """Form for creating and editing WorkOrder objects"""

    crossconnect = DynamicModelChoiceField(
        queryset=CrossConnect.objects.all(),
        required=True
    )
    comments = CommentField()

    fieldsets = (
        FieldSet('order_number', 'crossconnect', 'technician', 'action', name='Basic Information'),
        FieldSet('scheduled_date', 'completed_date', name='Dates'),
        FieldSet('before_state', 'after_state', name='State Changes'),
        FieldSet('is_validated', 'photo_url', name='Validation'),
        FieldSet('comments', 'tags', name='Additional Information'),
    )

    class Meta:
        model = WorkOrder
        fields = [
            'order_number', 'crossconnect', 'technician', 'action',
            'scheduled_date', 'completed_date', 'before_state', 'after_state',
            'is_validated', 'photo_url', 'comments', 'tags'
        ]
        widgets = {
            'before_state': forms.Textarea(attrs={'rows': 3}),
            'after_state': forms.Textarea(attrs={'rows': 3}),
        }


class WorkOrderFilterForm(NetBoxModelFilterSetForm):
    """Filter form for WorkOrder list view"""

    model = WorkOrder

    crossconnect_id = DynamicModelMultipleChoiceField(
        queryset=CrossConnect.objects.all(),
        required=False,
        label='Cross-Connect'
    )
    action = forms.MultipleChoiceField(
        choices=WorkOrderActionChoices,
        required=False
    )
    is_validated = forms.NullBooleanField(
        required=False,
        label='Validated'
    )
    tag = TagFilterField(model)


class BillingRecordForm(NetBoxModelForm):
    """Form for creating and editing BillingRecord objects"""

    crossconnect = DynamicModelChoiceField(
        queryset=CrossConnect.objects.all(),
        required=True
    )
    provider = DynamicModelChoiceField(
        queryset=Provider.objects.all(),
        required=False
    )
    comments = CommentField()

    fieldsets = (
        FieldSet('crossconnect', 'provider', 'order_reference', name='Basic Information'),
        FieldSet('monthly_charge', 'one_time_charge', name='Charges'),
        FieldSet('billing_start_date', 'billing_end_date', name='Billing Period'),
        FieldSet('expected_charge', 'actual_charge', 'invoice_number', name='Billing Comparison'),
        FieldSet('comments', 'tags', name='Additional Information'),
    )

    class Meta:
        model = BillingRecord
        fields = [
            'crossconnect', 'provider', 'order_reference', 'monthly_charge',
            'one_time_charge', 'billing_start_date', 'billing_end_date',
            'expected_charge', 'actual_charge', 'invoice_number', 'comments', 'tags'
        ]


class BillingRecordFilterForm(NetBoxModelFilterSetForm):
    """Filter form for BillingRecord list view"""

    model = BillingRecord

    crossconnect_id = DynamicModelMultipleChoiceField(
        queryset=CrossConnect.objects.all(),
        required=False,
        label='Cross-Connect'
    )
    provider_id = DynamicModelMultipleChoiceField(
        queryset=Provider.objects.all(),
        required=False,
        label='Provider'
    )
    tag = TagFilterField(model)


class AuditEventForm(NetBoxModelForm):
    """Form for creating and editing AuditEvent objects"""

    crossconnect = DynamicModelChoiceField(
        queryset=CrossConnect.objects.all(),
        required=True
    )
    comments = CommentField()

    fieldsets = (
        FieldSet('crossconnect', 'field_changed', name='Basic Information'),
        FieldSet('old_value', 'new_value', name='Changes'),
        FieldSet('reason', 'comments', 'tags', name='Additional Information'),
    )

    class Meta:
        model = AuditEvent
        fields = [
            'crossconnect', 'field_changed', 'old_value', 'new_value',
            'reason', 'comments', 'tags'
        ]
        widgets = {
            'old_value': forms.Textarea(attrs={'rows': 3}),
            'new_value': forms.Textarea(attrs={'rows': 3}),
        }


class AuditEventFilterForm(NetBoxModelFilterSetForm):
    """Filter form for AuditEvent list view"""

    model = AuditEvent

    crossconnect_id = DynamicModelMultipleChoiceField(
        queryset=CrossConnect.objects.all(),
        required=False,
        label='Cross-Connect'
    )
    tag = TagFilterField(model)


class PatchPathForm(NetBoxModelForm):
    """Form for creating and editing PatchPath objects"""

    crossconnect = DynamicModelChoiceField(
        queryset=CrossConnect.objects.all(),
        required=False
    )
    source_location = DynamicModelChoiceField(
        queryset=Location.objects.all(),
        required=True,
        label='Source Room/Location'
    )
    destination_location = DynamicModelChoiceField(
        queryset=Location.objects.all(),
        required=True,
        label='Destination Room/Location'
    )
    comments = CommentField()

    fieldsets = (
        FieldSet('reference', 'path_type', 'crossconnect', name='Basic Information'),
        FieldSet('source_location', 'destination_location', name='Locations'),
        FieldSet('total_length', 'is_active', name='Status'),
        FieldSet('comments', 'tags', name='Additional Information'),
    )

    class Meta:
        model = PatchPath
        fields = [
            'reference', 'crossconnect', 'path_type', 'source_location',
            'destination_location', 'total_length', 'is_active', 'comments', 'tags'
        ]


class PatchPathFilterForm(NetBoxModelFilterSetForm):
    """Filter form for PatchPath list view"""

    model = PatchPath

    crossconnect_id = DynamicModelMultipleChoiceField(
        queryset=CrossConnect.objects.all(),
        required=False,
        label='Cross-Connect'
    )
    source_location_id = DynamicModelMultipleChoiceField(
        queryset=Location.objects.all(),
        required=False,
        label='Source Location'
    )
    destination_location_id = DynamicModelMultipleChoiceField(
        queryset=Location.objects.all(),
        required=False,
        label='Destination Location'
    )
    path_type = forms.MultipleChoiceField(
        choices=PatchPathTypeChoices,
        required=False
    )
    is_active = forms.NullBooleanField(
        required=False,
        label='Active'
    )
    tag = TagFilterField(model)


class PatchSegmentForm(NetBoxModelForm):
    """Form for creating and editing PatchSegment objects"""

    patch_path = DynamicModelChoiceField(
        queryset=PatchPath.objects.all(),
        required=True
    )
    from_rack = DynamicModelChoiceField(
        queryset=Rack.objects.all(),
        required=False,
        label='Source Rack'
    )
    from_location = DynamicModelChoiceField(
        queryset=Location.objects.all(),
        required=True,
        label='Source Location'
    )
    to_rack = DynamicModelChoiceField(
        queryset=Rack.objects.all(),
        required=False,
        label='Destination Rack'
    )
    to_location = DynamicModelChoiceField(
        queryset=Location.objects.all(),
        required=True,
        label='Destination Location'
    )
    comments = CommentField()

    fieldsets = (
        FieldSet('patch_path', 'sequence', 'cable_type', name='Basic Information'),
        FieldSet('from_location', 'from_rack', 'from_panel', 'from_port', name='Source'),
        FieldSet('to_location', 'to_rack', 'to_panel', 'to_port', name='Destination'),
        FieldSet('cable_length', 'cable_color', 'cable_label', name='Cable Details'),
        FieldSet('comments', 'tags', name='Additional Information'),
    )

    class Meta:
        model = PatchSegment
        fields = [
            'patch_path', 'sequence', 'from_rack', 'from_location', 'from_panel',
            'from_port', 'to_rack', 'to_location', 'to_panel', 'to_port',
            'cable_type', 'cable_length', 'cable_color', 'cable_label', 'comments', 'tags'
        ]


class PatchSegmentFilterForm(NetBoxModelFilterSetForm):
    """Filter form for PatchSegment list view"""

    model = PatchSegment

    patch_path_id = DynamicModelMultipleChoiceField(
        queryset=PatchPath.objects.all(),
        required=False,
        label='Patch Path'
    )
    from_location_id = DynamicModelMultipleChoiceField(
        queryset=Location.objects.all(),
        required=False,
        label='Source Location'
    )
    to_location_id = DynamicModelMultipleChoiceField(
        queryset=Location.objects.all(),
        required=False,
        label='Destination Location'
    )
    from_rack_id = DynamicModelMultipleChoiceField(
        queryset=Rack.objects.all(),
        required=False,
        label='Source Rack'
    )
    to_rack_id = DynamicModelMultipleChoiceField(
        queryset=Rack.objects.all(),
        required=False,
        label='Destination Rack'
    )
    cable_type = forms.MultipleChoiceField(
        choices=CrossConnectTypeChoices,
        required=False
    )
    tag = TagFilterField(model)

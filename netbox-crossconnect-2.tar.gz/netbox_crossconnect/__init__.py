from netbox.plugins import PluginConfig


class CrossConnectConfig(PluginConfig):
    name = 'netbox_crossconnect'
    verbose_name = 'Cross-Connect Management'
    description = 'Manage cross-connects, physical patching, and circuit lifecycle'
    version = '1.0.0'
    author = 'Your Name'
    author_email = 'your.email@example.com'
    base_url = 'crossconnect'
    required_settings = []
    default_settings = {
        'enable_billing': True,
        'enable_work_orders': True,
    }
    min_version = '4.0.0'
    max_version = '4.9.99'


config = CrossConnectConfig

import django_tables2 as tables
from netbox.tables import NetBoxTable, columns

from .models import CrossConnect, CrossConnectEndpoint, WorkOrder, BillingRecord, AuditEvent, PatchPath, PatchSegment


class CrossConnectTable(NetBoxTable):
    """Table for displaying CrossConnect objects in list view"""

    reference = tables.Column(
        linkify=True,
        verbose_name='Reference'
    )
    tenant = tables.Column(
        linkify=True,
        verbose_name='Customer'
    )
    provider = tables.Column(
        linkify=True,
        verbose_name='Operator'
    )
    site = tables.Column(
        linkify=True
    )
    location = tables.Column(
        linkify=True,
        verbose_name='Room/MMR'
    )
    type = tables.Column(
        verbose_name='Type'
    )
    capacity = tables.Column(
        verbose_name='Capacity'
    )
    status = columns.ChoiceFieldColumn(
        verbose_name='Status'
    )
    order_date = tables.DateColumn(
        verbose_name='Order Date'
    )
    delivery_date = tables.DateColumn(
        verbose_name='Delivery Date'
    )
    monthly_cost = tables.Column(
        verbose_name='MRC'
    )
    comments = columns.MarkdownColumn()
    tags = columns.TagColumn(
        url_name='plugins:netbox_crossconnect:crossconnect_list'
    )

    class Meta(NetBoxTable.Meta):
        model = CrossConnect
        fields = (
            'pk', 'id', 'reference', 'tenant', 'provider', 'site', 'location',
            'type', 'capacity', 'status', 'order_date', 'delivery_date',
            'monthly_cost', 'one_time_cost', 'comments', 'tags', 'created',
            'last_updated', 'actions'
        )
        default_columns = (
            'reference', 'tenant', 'provider', 'site', 'location', 'type',
            'capacity', 'status', 'order_date'
        )


class CrossConnectEndpointTable(NetBoxTable):
    """Table for displaying CrossConnectEndpoint objects in list view"""

    crossconnect = tables.Column(
        linkify=True,
        verbose_name='Cross-Connect'
    )
    side = columns.ChoiceFieldColumn(
        verbose_name='Side'
    )
    endpoint_type = columns.ChoiceFieldColumn(
        verbose_name='Endpoint Type'
    )
    rack = tables.Column(
        linkify=True
    )
    rack_position = tables.Column(
        verbose_name='Position'
    )
    port_label = tables.Column(
        verbose_name='Port'
    )
    patch_label = tables.Column(
        verbose_name='Patch Label'
    )
    cable_length = tables.Column(
        verbose_name='Length (m)'
    )
    cable_color = tables.Column(
        verbose_name='Color'
    )
    comments = columns.MarkdownColumn()
    tags = columns.TagColumn(
        url_name='plugins:netbox_crossconnect:crossconnectendpoint_list'
    )

    class Meta(NetBoxTable.Meta):
        model = CrossConnectEndpoint
        fields = (
            'pk', 'id', 'crossconnect', 'side', 'endpoint_type', 'rack',
            'rack_position', 'port_label', 'patch_label', 'cable_length',
            'cable_color', 'polarity', 'comments', 'tags', 'created',
            'last_updated', 'actions'
        )
        default_columns = (
            'crossconnect', 'side', 'endpoint_type', 'rack', 'port_label',
            'patch_label', 'cable_color'
        )


class WorkOrderTable(NetBoxTable):
    """Table for displaying WorkOrder objects in list view"""

    order_number = tables.Column(
        linkify=True,
        verbose_name='Order #'
    )
    crossconnect = tables.Column(
        linkify=True,
        verbose_name='Cross-Connect'
    )
    technician = tables.Column(
        verbose_name='Technician'
    )
    action = columns.ChoiceFieldColumn(
        verbose_name='Action'
    )
    scheduled_date = tables.DateTimeColumn(
        verbose_name='Scheduled'
    )
    completed_date = tables.DateTimeColumn(
        verbose_name='Completed'
    )
    is_validated = columns.BooleanColumn(
        verbose_name='Validated'
    )
    photo_url = tables.TemplateColumn(
        template_code='{% if value %}<a href="{{ value }}" target="_blank">View</a>{% else %}-{% endif %}',
        verbose_name='Photo'
    )
    comments = columns.MarkdownColumn()
    tags = columns.TagColumn(
        url_name='plugins:netbox_crossconnect:workorder_list'
    )

    class Meta(NetBoxTable.Meta):
        model = WorkOrder
        fields = (
            'pk', 'id', 'order_number', 'crossconnect', 'technician', 'action',
            'scheduled_date', 'completed_date', 'is_validated', 'photo_url',
            'before_state', 'after_state', 'comments', 'tags', 'created',
            'last_updated', 'actions'
        )
        default_columns = (
            'order_number', 'crossconnect', 'technician', 'action',
            'scheduled_date', 'completed_date', 'is_validated'
        )


class BillingRecordTable(NetBoxTable):
    """Table for displaying BillingRecord objects in list view"""

    crossconnect = tables.Column(
        linkify=True,
        verbose_name='Cross-Connect'
    )
    provider = tables.Column(
        linkify=True
    )
    order_reference = tables.Column(
        verbose_name='Order Ref'
    )
    monthly_charge = tables.Column(
        verbose_name='MRC'
    )
    one_time_charge = tables.Column(
        verbose_name='NRC'
    )
    billing_start_date = tables.DateColumn(
        verbose_name='Start Date'
    )
    billing_end_date = tables.DateColumn(
        verbose_name='End Date'
    )
    expected_charge = tables.Column(
        verbose_name='Expected'
    )
    actual_charge = tables.Column(
        verbose_name='Actual'
    )
    variance = tables.TemplateColumn(
        template_code='''
            {% if record.variance %}
                {% if record.variance > 0 %}
                    <span class="text-danger">+{{ record.variance }}</span>
                {% elif record.variance < 0 %}
                    <span class="text-success">{{ record.variance }}</span>
                {% else %}
                    {{ record.variance }}
                {% endif %}
            {% else %}
                -
            {% endif %}
        ''',
        verbose_name='Variance'
    )
    invoice_number = tables.Column(
        verbose_name='Invoice #'
    )
    comments = columns.MarkdownColumn()
    tags = columns.TagColumn(
        url_name='plugins:netbox_crossconnect:billingrecord_list'
    )

    class Meta(NetBoxTable.Meta):
        model = BillingRecord
        fields = (
            'pk', 'id', 'crossconnect', 'provider', 'order_reference',
            'monthly_charge', 'one_time_charge', 'billing_start_date',
            'billing_end_date', 'expected_charge', 'actual_charge', 'variance',
            'invoice_number', 'comments', 'tags', 'created', 'last_updated',
            'actions'
        )
        default_columns = (
            'crossconnect', 'provider', 'billing_start_date', 'monthly_charge',
            'expected_charge', 'actual_charge', 'variance'
        )


class AuditEventTable(NetBoxTable):
    """Table for displaying AuditEvent objects in list view"""

    crossconnect = tables.Column(
        linkify=True,
        verbose_name='Cross-Connect'
    )
    user = tables.Column(
        linkify=True,
        verbose_name='User'
    )
    timestamp = tables.DateTimeColumn(
        verbose_name='Timestamp'
    )
    field_changed = tables.Column(
        verbose_name='Field'
    )
    old_value = tables.Column(
        verbose_name='Old Value'
    )
    new_value = tables.Column(
        verbose_name='New Value'
    )
    reason = tables.Column(
        verbose_name='Reason'
    )
    comments = columns.MarkdownColumn()
    tags = columns.TagColumn(
        url_name='plugins:netbox_crossconnect:auditevent_list'
    )

    class Meta(NetBoxTable.Meta):
        model = AuditEvent
        fields = (
            'pk', 'id', 'crossconnect', 'user', 'timestamp', 'field_changed',
            'old_value', 'new_value', 'reason', 'comments', 'tags', 'created',
            'last_updated', 'actions'
        )
        default_columns = (
            'timestamp', 'crossconnect', 'user', 'field_changed',
            'old_value', 'new_value', 'reason'
        )


class PatchPathTable(NetBoxTable):
    """Table for displaying PatchPath objects in list view"""

    reference = tables.Column(
        linkify=True,
        verbose_name='Reference'
    )
    path_type = columns.ChoiceFieldColumn(
        verbose_name='Type'
    )
    crossconnect = tables.Column(
        linkify=True,
        verbose_name='Cross-Connect'
    )
    source_location = tables.Column(
        linkify=True,
        verbose_name='Source'
    )
    destination_location = tables.Column(
        linkify=True,
        verbose_name='Destination'
    )
    total_length = tables.Column(
        verbose_name='Length (m)'
    )
    is_active = columns.BooleanColumn(
        verbose_name='Active'
    )
    actions = tables.TemplateColumn(
        template_code='''
            <a href="{% url 'plugins:netbox_crossconnect:patchpath_trace' pk=record.pk %}" class="btn btn-sm btn-primary" title="View Trace">
                <i class="mdi mdi-chart-line"></i>
            </a>
        ''',
        verbose_name='Trace',
        orderable=False
    )
    comments = columns.MarkdownColumn()
    tags = columns.TagColumn(
        url_name='plugins:netbox_crossconnect:patchpath_list'
    )

    class Meta(NetBoxTable.Meta):
        model = PatchPath
        fields = (
            'pk', 'id', 'reference', 'path_type', 'crossconnect', 'source_location',
            'destination_location', 'total_length', 'is_active', 'comments',
            'tags', 'created', 'last_updated', 'actions'
        )
        default_columns = (
            'reference', 'path_type', 'source_location', 'destination_location',
            'total_length', 'is_active', 'actions'
        )


class PatchSegmentTable(NetBoxTable):
    """Table for displaying PatchSegment objects in list view"""

    patch_path = tables.Column(
        linkify=True,
        verbose_name='Patch Path'
    )
    sequence = tables.Column(
        verbose_name='Seq'
    )
    from_location = tables.Column(
        linkify=True,
        verbose_name='From Location'
    )
    from_rack = tables.Column(
        linkify=True,
        verbose_name='From Rack'
    )
    from_panel = tables.Column(
        verbose_name='From Panel'
    )
    from_port = tables.Column(
        verbose_name='From Port'
    )
    to_location = tables.Column(
        linkify=True,
        verbose_name='To Location'
    )
    to_rack = tables.Column(
        linkify=True,
        verbose_name='To Rack'
    )
    to_panel = tables.Column(
        verbose_name='To Panel'
    )
    to_port = tables.Column(
        verbose_name='To Port'
    )
    cable_type = columns.ChoiceFieldColumn(
        verbose_name='Cable Type'
    )
    cable_length = tables.Column(
        verbose_name='Length (m)'
    )
    cable_color = tables.Column(
        verbose_name='Color'
    )
    cable_label = tables.Column(
        verbose_name='Label'
    )
    comments = columns.MarkdownColumn()
    tags = columns.TagColumn(
        url_name='plugins:netbox_crossconnect:patchsegment_list'
    )

    class Meta(NetBoxTable.Meta):
        model = PatchSegment
        fields = (
            'pk', 'id', 'patch_path', 'sequence', 'from_location', 'from_rack',
            'from_panel', 'from_port', 'to_location', 'to_rack', 'to_panel',
            'to_port', 'cable_type', 'cable_length', 'cable_color', 'cable_label',
            'comments', 'tags', 'created', 'last_updated', 'actions'
        )
        default_columns = (
            'patch_path', 'sequence', 'from_location', 'from_panel', 'to_location',
            'to_panel', 'cable_type', 'cable_length'
        )

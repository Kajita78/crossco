from setuptools import setup, find_packages

setup(
    name='netbox-crossconnect',
    version='1.0.0',
    description='NetBox plugin for managing cross-connects and physical patching',
    url='https://github.com/yourusername/netbox-crossconnect',
    author='Your Name',
    license='Apache-2.0',
    install_requires=[],
    packages=find_packages(),
    include_package_data=True,
    zip_safe=False,
)

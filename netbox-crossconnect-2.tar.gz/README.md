# NetBox Cross-Connect Plugin

A comprehensive NetBox plugin for managing cross-connects, physical patching, and circuit lifecycle in datacenters.

## Features

This plugin provides complete lifecycle management for datacenter cross-connects with:

### Core Models

1. **CrossConnect** - Main cross-connect request tracking
   - Customer/tenant association
   - Operator/provider tracking
   - Site and location (room/MMR) management
   - Cable type (copper, fiber SM/MM)
   - Capacity (1G, 10G, 40G, 100G, 400G+)
   - Status workflow (requested → ordered → in-progress → active → suspended → terminated)
   - Order and delivery date tracking
   - Cost tracking (MRC and NRC)

2. **CrossConnectEndpoint** - Side A/B endpoint details
   - Physical location (rack, position)
   - Port and patch labeling
   - Cable specifications (length, color, polarity)
   - Support for various endpoint types:
     - Patch panels
     - Device interfaces
     - Circuit terminations
     - Free positions

3. **WorkOrder** - Physical intervention tracking
   - Technician assignment
   - Action types (create, move, add, change, delete)
   - Before/after state documentation
   - Scheduled and completion dates
   - Validation workflow
   - Photo documentation support

4. **BillingRecord** - Financial tracking
   - Provider billing details
   - Monthly (MRC) and one-time (NRC) charges
   - Billing period management
   - Expected vs. actual charge comparison
   - Automatic variance calculation
   - Invoice tracking

5. **AuditEvent** - Change traceability
   - User action logging
   - Field-level change tracking
   - Old/new value comparison
   - Change reason documentation
   - Timestamp tracking

6. **PatchPath** - Inter-room patching and MMR management
   - Support for direct, inter-room, backbone, and MMR connections
   - Path type classification
   - Source and destination location tracking
   - Total path length calculation
   - Active/inactive status management
   - Integration with cross-connects

7. **PatchSegment** - Detailed path segment tracking
   - Sequential segment ordering
   - Per-segment source and destination details
   - Rack, panel, and port information
   - Cable type, length, color, and labeling
   - Support for complex multi-segment paths

### Visual Tracing Features

- **Path Trace Visualization** - Interactive graphical view of individual patch paths
  - Visual representation of all segments in a path
  - Node-based topology showing locations, racks, panels, and ports
  - Edge visualization with cable types, lengths, and colors
  - Path metrics including total length, locations crossed, and cable types

- **Network Topology View** - Complete cross-connect topology visualization
  - Site-wide or location-specific topology maps
  - Interactive graph with zoom, pan, and navigation
  - Real-time path filtering and display
  - Connection details on click

- **MMR Connections** - Meet-Me Room connection visualization
  - All paths passing through a specific MMR
  - Star topology centered on MMR location
  - Connection statistics and metrics

## Installation

### Requirements

- NetBox 4.0.0 or higher (testé sur v4.5.6)
- Python 3.10 or higher
- Accès root ou sudo sur le serveur NetBox

### Méthode 1 : Installation depuis le code source (recommandée)

#### Étape 1 : Télécharger le plugin

```bash
# Se connecter au serveur NetBox en SSH
ssh user@your-netbox-server

# Aller dans le répertoire NetBox
cd /opt/netbox

# Activer l'environnement virtuel Python de NetBox
source venv/bin/activate

# Télécharger le plugin (plusieurs options)

# Option A : Depuis un dépôt Git
git clone https://github.com/yourusername/netbox-crossconnect.git
cd netbox-crossconnect

# Option B : Depuis un fichier ZIP téléchargé
# Uploader le ZIP sur le serveur puis :
unzip netbox-crossconnect.zip
cd netbox-crossconnect

# Option C : Depuis un répertoire local
# Copier le dossier netbox_crossconnect directement
```

#### Étape 2 : Installer le plugin

```bash
# Toujours dans l'environnement virtuel activé
pip install .

# Ou pour une installation en mode développement
pip install -e .

# Vérifier l'installation
pip list | grep netbox-crossconnect
```

#### Étape 3 : Configurer NetBox

Éditer le fichier de configuration NetBox :

```bash
# Ouvrir le fichier de configuration
sudo nano /opt/netbox/netbox/netbox/configuration.py
```

Ajouter le plugin dans la section `PLUGINS` :

```python
PLUGINS = [
    'netbox_crossconnect',
    # ... autres plugins existants
]

# Configuration optionnelle du plugin
PLUGINS_CONFIG = {
    'netbox_crossconnect': {
        'enable_billing': True,        # Activer la facturation
        'enable_work_orders': True,    # Activer les ordres de travail
    }
}
```

Sauvegarder et fermer (Ctrl+X, puis Y, puis Entrée).

#### Étape 4 : Exécuter les migrations de base de données

```bash
# Aller dans le répertoire NetBox
cd /opt/netbox/netbox

# Exécuter les migrations
python manage.py migrate netbox_crossconnect

# Vérifier que les migrations sont bien appliquées
python manage.py showmigrations netbox_crossconnect
```

Vous devriez voir :

```
netbox_crossconnect
 [X] 0001_initial
```

#### Étape 5 : Collecter les fichiers statiques

```bash
python manage.py collectstatic --no-input
```

#### Étape 6 : Redémarrer les services NetBox

```bash
# Pour une installation systemd (méthode standard)
sudo systemctl restart netbox netbox-rq

# Vérifier que les services sont bien démarrés
sudo systemctl status netbox
sudo systemctl status netbox-rq

# Alternative : pour une installation avec supervisord
sudo supervisorctl restart netbox
sudo supervisorctl restart netbox-rq
```

#### Étape 7 : Vérifier l'installation

1. Ouvrir NetBox dans votre navigateur : `https://your-netbox-server/`
2. Se connecter avec vos identifiants
3. Vérifier qu'un nouveau menu "Cross-Connects" apparaît dans la barre de navigation

### Méthode 2 : Installation depuis PyPI (quand disponible)

```bash
cd /opt/netbox
source venv/bin/activate
pip install netbox-crossconnect
```

Puis suivre les étapes 3 à 7 ci-dessus.

### Méthode 3 : Installation manuelle

Si vous ne pouvez pas utiliser pip :

```bash
# Copier le dossier netbox_crossconnect dans le répertoire des plugins
sudo cp -r netbox_crossconnect /opt/netbox/netbox/netbox/plugins/

# Ajuster les permissions
sudo chown -R netbox:netbox /opt/netbox/netbox/netbox/plugins/netbox_crossconnect
```

Puis suivre les étapes 3 à 7 ci-dessus.

### Dépannage

#### Le menu n'apparaît pas
- Vérifier que le plugin est bien dans `PLUGINS` dans `configuration.py`
- Vérifier les logs : `sudo journalctl -u netbox -n 50`
- Redémarrer les services

#### Erreur de migration
```bash
# Réinitialiser les migrations si nécessaire
python manage.py migrate netbox_crossconnect zero
python manage.py migrate netbox_crossconnect
```

#### Erreur de permissions
```bash
sudo chown -R netbox:netbox /opt/netbox
```

### Désinstallation

```bash
# 1. Supprimer le plugin de configuration.py
sudo nano /opt/netbox/netbox/netbox/configuration.py
# Retirer 'netbox_crossconnect' de PLUGINS

# 2. Annuler les migrations (optionnel, supprime les données)
cd /opt/netbox/netbox
python manage.py migrate netbox_crossconnect zero

# 3. Désinstaller le package
source /opt/netbox/venv/bin/activate
pip uninstall netbox-crossconnect

# 4. Redémarrer les services
sudo systemctl restart netbox netbox-rq
```

## Usage

### Web Interface

After installation, the plugin adds a "Cross-Connects" menu to NetBox with the following sections:

#### Cross-Connects Section
- **Cross-Connects** - View and manage all cross-connect requests
- **Endpoints** - Manage endpoint configurations (A/B sides)

#### Patch Paths & Tracing Section
- **Patch Paths** - Manage inter-room and MMR patch paths
- **Patch Segments** - Configure individual path segments
- **Network Topology** - Interactive visualization of complete network topology

#### Operations Section
- **Work Orders** - Track physical interventions and changes

#### Billing & Audit Section
- **Billing Records** - Monitor costs and billing discrepancies
- **Audit Events** - Review change history and traceability

### REST API

The plugin exposes a full REST API at `/api/plugins/crossconnect/`:

#### Endpoints

- `/api/plugins/crossconnect/crossconnects/` - Cross-connect management
- `/api/plugins/crossconnect/endpoints/` - Endpoint management
- `/api/plugins/crossconnect/patch-paths/` - Patch path management
- `/api/plugins/crossconnect/patch-segments/` - Patch segment management
- `/api/plugins/crossconnect/work-orders/` - Work order management
- `/api/plugins/crossconnect/billing-records/` - Billing record management
- `/api/plugins/crossconnect/audit-events/` - Audit event management
- `/api/plugins/crossconnect/topology/data/` - Network topology data (JSON)
- `/api/plugins/crossconnect/path-trace/<id>/` - Path trace data (JSON)

#### Example API Usage

Create a cross-connect:

```bash
curl -X POST \
  http://netbox.example.com/api/plugins/crossconnect/crossconnects/ \
  -H 'Authorization: Token YOUR_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "reference": "XC-2024-001",
    "site": 1,
    "type": "fiber-sm",
    "capacity": "10g",
    "status": "requested",
    "monthly_cost": "500.00"
  }'
```

List cross-connects by status:

```bash
curl -X GET \
  'http://netbox.example.com/api/plugins/crossconnect/crossconnects/?status=active' \
  -H 'Authorization: Token YOUR_TOKEN'
```

### Integration with NetBox Objects

The plugin integrates seamlessly with NetBox core models:

- **Tenancy** - Link cross-connects to customers/tenants
- **DCIM** - Associate with sites, locations, racks, and devices
- **Circuits** - Connect to providers and circuits
- **Tags** - Use NetBox tagging system for categorization

### Workflow Example

1. **Request Phase**
   - Create a cross-connect with status "requested"
   - Define customer, operator, site, and technical requirements
   - Add cost estimates

2. **Order Phase**
   - Update status to "ordered"
   - Set order date
   - Create billing record with expected charges

3. **Installation Phase**
   - Update status to "in-progress"
   - Create work order for technician
   - Define endpoints (A and B sides)
   - Document physical details (rack, port, cable specs)

4. **Activation Phase**
   - Complete work order with before/after states
   - Upload photo documentation
   - Update status to "active"
   - Set delivery date

5. **Billing Phase**
   - Update billing record with actual charges
   - Review variance between expected and actual costs
   - Link invoice reference

6. **Audit Trail**
   - Automatic audit events track all changes
   - Review who changed what and when
   - Document reasons for changes

## Configuration Options

Available settings in `PLUGINS_CONFIG`:

```python
PLUGINS_CONFIG = {
    'netbox_crossconnect': {
        # Enable billing functionality (default: True)
        'enable_billing': True,

        # Enable work order tracking (default: True)
        'enable_work_orders': True,
    }
}
```

## Database Schema

The plugin creates the following database tables:

- `netbox_crossconnect_crossconnect` - Main cross-connect data
- `netbox_crossconnect_crossconnectendpoint` - Endpoint configurations
- `netbox_crossconnect_patchpath` - Inter-room patch paths
- `netbox_crossconnect_patchsegment` - Path segment details
- `netbox_crossconnect_workorder` - Work order tracking
- `netbox_crossconnect_billingrecord` - Billing information
- `netbox_crossconnect_auditevent` - Audit trail

## Permissions

The plugin uses NetBox's standard permission system:

- `netbox_crossconnect.view_*` - View objects
- `netbox_crossconnect.add_*` - Create new objects
- `netbox_crossconnect.change_*` - Modify existing objects
- `netbox_crossconnect.delete_*` - Delete objects

Assign permissions through NetBox's user and group management.

## Reporting

Use NetBox's built-in reporting features to:

- List cross-connects by status
- Identify billing variances
- Track pending work orders
- Monitor cross-connect lifecycle
- Generate cost reports

## Support

For issues and feature requests, please use the GitHub issue tracker:
https://github.com/yourusername/netbox-crossconnect/issues

## License

Apache License 2.0

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## Credits

Developed for NetBox datacenter infrastructure management.

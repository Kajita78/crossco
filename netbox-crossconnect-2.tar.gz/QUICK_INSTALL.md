# Installation Rapide - NetBox Cross-Connect Plugin

## Installation depuis le fichier tar.gz

### Étape 1: Télécharger et extraire

```bash
# Se connecter au serveur NetBox
ssh user@netbox-server

# Aller dans un répertoire temporaire
cd /tmp

# Copier le fichier tar.gz sur le serveur (depuis votre machine locale)
# scp netbox-crossconnect-1.0.0.tar.gz user@netbox-server:/tmp/

# Extraire l'archive
tar -xzf netbox-crossconnect-1.0.0.tar.gz
```

### Étape 2: Installer le plugin

```bash
# Aller dans le répertoire NetBox et activer l'environnement virtuel
cd /opt/netbox
source venv/bin/activate

# Installer le plugin depuis le fichier extrait
pip install /tmp/netbox-crossconnect-1.0.0.tar.gz

# Vérifier l'installation
pip list | grep netbox-crossconnect
```

### Étape 3: Configurer NetBox

Éditer le fichier de configuration:

```bash
sudo nano /opt/netbox/netbox/netbox/configuration.py
```

Ajouter le plugin:

```python
PLUGINS = [
    'netbox_crossconnect',
]

# Configuration optionnelle
PLUGINS_CONFIG = {
    'netbox_crossconnect': {
        'enable_billing': True,
        'enable_work_orders': True,
    }
}
```

### Étape 4: Appliquer les migrations

```bash
cd /opt/netbox/netbox
python manage.py migrate netbox_crossconnect
python manage.py collectstatic --no-input
```

### Étape 5: Redémarrer NetBox

```bash
sudo systemctl restart netbox netbox-rq
sudo systemctl status netbox
```

### Étape 6: Vérifier

1. Ouvrir NetBox: `https://your-netbox-server/`
2. Le menu "Cross-Connects" doit apparaître avec les sections:
   - Cross-Connects
   - Patch Paths & Tracing
   - Operations
   - Billing & Audit

## Fonctionnalités Principales

### Brassage Inter-Salles et MMR
- Créer des chemins de brassage complexes
- Gérer les segments avec détails (rack, panneau, port, câble)
- Support MMR (Meet-Me Room)

### Visualisation Graphique
- **Path Trace**: Voir le traçage visuel d'un chemin
- **Network Topology**: Vue complète de la topologie réseau
- **MMR Connections**: Connexions traversant un MMR

### Navigation Rapide

1. **Créer un chemin de brassage**:
   - Cross-Connects → Patch Paths & Tracing → Patch Paths → Add

2. **Ajouter des segments**:
   - Ouvrir un Patch Path → Add Segment

3. **Voir le traçage visuel**:
   - Ouvrir un Patch Path → View Trace

4. **Voir la topologie réseau**:
   - Cross-Connects → Patch Paths & Tracing → Network Topology

## API REST

Endpoints disponibles:

```bash
# Chemins de brassage
GET    /api/plugins/crossconnect/patch-paths/
POST   /api/plugins/crossconnect/patch-paths/
GET    /api/plugins/crossconnect/patch-paths/{id}/

# Segments
GET    /api/plugins/crossconnect/patch-segments/
POST   /api/plugins/crossconnect/patch-segments/

# Topologie
GET    /api/plugins/crossconnect/topology/data/
GET    /api/plugins/crossconnect/topology/data/?location={id}

# Traçage
GET    /api/plugins/crossconnect/path-trace/{id}/
```

## Documentation Complète

- **README.md**: Documentation générale du plugin
- **PATCH_PATHS_GUIDE.md**: Guide complet du brassage inter-salles
- **INSTALL.md**: Instructions d'installation détaillées

## Support

Pour les problèmes ou questions:
- Consulter les logs: `sudo journalctl -u netbox -n 50`
- Vérifier les migrations: `python manage.py showmigrations netbox_crossconnect`

## Mise à jour

Pour mettre à jour vers une nouvelle version:

```bash
cd /opt/netbox
source venv/bin/activate
pip install --upgrade /path/to/netbox-crossconnect-X.X.X.tar.gz
python manage.py migrate netbox_crossconnect
python manage.py collectstatic --no-input
sudo systemctl restart netbox netbox-rq
```

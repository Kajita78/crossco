# Guide de Brassage Inter-Salles et Traçage Visuel

Ce guide explique comment utiliser les fonctionnalités de brassage inter-salles, de gestion MMR et de traçage visuel graphique dans le plugin NetBox Cross-Connect.

## Vue d'ensemble

Le plugin fournit maintenant des capacités avancées pour gérer les chemins de brassage complexes qui traversent plusieurs salles, incluant:

- **Brassage Direct**: Connexions simples dans une même salle
- **Brassage Inter-Salles**: Chemins qui traversent plusieurs salles
- **Backbone**: Liens d'infrastructure principaux
- **MMR (Meet-Me Room)**: Salles de brassage communes

## Modèles de Données

### PatchPath (Chemin de Brassage)

Un PatchPath représente un chemin complet entre deux locations avec ses caractéristiques:

- **Reference**: Identifiant unique du chemin
- **Type de Chemin**: Direct, Inter-Salles, Backbone, ou MMR
- **Location Source**: Salle de départ
- **Location Destination**: Salle d'arrivée
- **Longueur Totale**: Calculée automatiquement depuis les segments
- **Statut Actif**: Indique si le chemin est en service

### PatchSegment (Segment de Chemin)

Chaque segment représente une portion du chemin avec des détails précis:

- **Séquence**: Ordre dans le chemin (1, 2, 3...)
- **Source**: Location, Rack, Panneau, Port
- **Destination**: Location, Rack, Panneau, Port
- **Câble**: Type, longueur, couleur, étiquette

## Utilisation via l'Interface Web

### 1. Créer un Chemin de Brassage

1. Aller dans **Cross-Connects > Patch Paths & Tracing > Patch Paths**
2. Cliquer sur **Add**
3. Remplir les informations:
   - **Reference**: Par exemple "PATH-SALLE1-SALLE2-001"
   - **Type de Chemin**: Sélectionner le type approprié
   - **Source Location**: Salle de départ
   - **Destination Location**: Salle d'arrivée
   - **Cross-Connect**: (Optionnel) Lier à un cross-connect existant
   - **Is Active**: Cocher si le chemin est en service
4. Sauvegarder

### 2. Ajouter des Segments au Chemin

1. Ouvrir le chemin créé
2. Cliquer sur **Add Segment**
3. Pour chaque segment, renseigner:
   - **Patch Path**: Sélectionner le chemin parent
   - **Sequence**: Numéro d'ordre (1 pour le premier segment)
   - **Source**: Location, Rack, Panneau, Port de départ
   - **Destination**: Location, Rack, Panneau, Port d'arrivée
   - **Cable Type**: Type de câble (Cuivre, Fibre SM, Fibre MM)
   - **Cable Length**: Longueur en mètres
   - **Cable Color**: Couleur du câble
   - **Cable Label**: Étiquette d'identification
4. Répéter pour chaque segment du chemin

### 3. Visualiser le Traçage d'un Chemin

1. Ouvrir un Patch Path
2. Cliquer sur le bouton **View Trace**
3. La vue de traçage affiche:
   - **Graphe Interactif**: Visualisation du chemin avec tous les segments
   - **Métriques**: Statistiques du chemin (longueur totale, nombre de segments, etc.)
   - **Tableau des Segments**: Liste détaillée de tous les segments

### 4. Visualiser la Topologie Réseau Complète

1. Aller dans **Cross-Connects > Patch Paths & Tracing > Network Topology**
2. La vue affiche:
   - **Graphe Complet**: Tous les chemins de brassage
   - **Filtres**: Par site ou location
   - **Contrôles Interactifs**:
     - Zoom: Molette de la souris
     - Déplacer: Glisser-déposer
     - Voir Détails: Cliquer sur une connexion
3. Utiliser les boutons:
   - **Refresh**: Recharger la topologie
   - **Fit View**: Ajuster la vue pour tout voir

### 5. Visualiser les Connexions MMR

1. Identifier la location MMR dans NetBox (DCIM > Locations)
2. Aller à l'URL: `/plugins/crossconnect/mmr/<location_id>/connections/`
3. La vue affiche:
   - **Topologie en Étoile**: MMR au centre, toutes les connexions autour
   - **Liste des Chemins**: Tableau détaillé de tous les chemins traversant le MMR
   - **Statistiques**: Nombre total de connexions

## Utilisation via l'API REST

### Créer un Chemin de Brassage

```bash
curl -X POST \
  http://netbox.example.com/api/plugins/crossconnect/patch-paths/ \
  -H 'Authorization: Token YOUR_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "reference": "PATH-ROOM1-ROOM2-001",
    "path_type": "inter-room",
    "source_location": 10,
    "destination_location": 12,
    "is_active": true,
    "total_length": 150.0
  }'
```

### Ajouter un Segment

```bash
curl -X POST \
  http://netbox.example.com/api/plugins/crossconnect/patch-segments/ \
  -H 'Authorization: Token YOUR_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "patch_path": 1,
    "sequence": 1,
    "from_location": 10,
    "from_rack": 5,
    "from_panel": "PP01",
    "from_port": "Port 1",
    "to_location": 12,
    "to_rack": 8,
    "to_panel": "PP05",
    "to_port": "Port 12",
    "cable_type": "fiber-sm",
    "cable_length": 75.5,
    "cable_color": "yellow",
    "cable_label": "FB-001"
  }'
```

### Obtenir les Données de Traçage

```bash
curl -X GET \
  http://netbox.example.com/api/plugins/crossconnect/path-trace/1/ \
  -H 'Authorization: Token YOUR_TOKEN'
```

### Obtenir la Topologie Réseau

```bash
# Topologie complète
curl -X GET \
  http://netbox.example.com/api/plugins/crossconnect/topology/data/ \
  -H 'Authorization: Token YOUR_TOKEN'

# Topologie filtrée par site
curl -X GET \
  'http://netbox.example.com/api/plugins/crossconnect/topology/data/?site=1' \
  -H 'Authorization: Token YOUR_TOKEN'

# Topologie filtrée par location
curl -X GET \
  'http://netbox.example.com/api/plugins/crossconnect/topology/data/?location=10' \
  -H 'Authorization: Token YOUR_TOKEN'
```

## Cas d'Usage Typiques

### Cas 1: Brassage Simple (Direct)

**Scénario**: Connecter deux équipements dans la même salle

1. Créer un PatchPath de type "Direct"
2. Ajouter 1 segment:
   - Source: Rack A, Panneau 1, Port 5
   - Destination: Rack B, Panneau 2, Port 12

### Cas 2: Brassage Inter-Salles

**Scénario**: Connecter une salle serveur à une salle réseau via un backbone

1. Créer un PatchPath de type "Inter-Room"
2. Ajouter 3 segments:
   - Segment 1: Salle Serveur → Backbone (panneau de sortie)
   - Segment 2: Backbone → Backbone (câble entre salles)
   - Segment 3: Backbone → Salle Réseau (panneau d'entrée)

### Cas 3: Connexion via MMR

**Scénario**: Deux clients se connectent via une salle de brassage commune

1. Créer un PatchPath de type "MMR"
2. Ajouter 4 segments:
   - Segment 1: Cage Client A → MMR (panneau client A)
   - Segment 2: MMR panneau A → MMR panneau B
   - Segment 3: MMR panneau B → Cage Client B
   - Segment 4: Panneau Client B → Équipement

### Cas 4: Backbone Multi-Sites

**Scénario**: Liaison entre deux datacenters

1. Créer un PatchPath de type "Backbone"
2. Ajouter tous les segments nécessaires
3. Documenter chaque tronçon avec précision

## Métriques et Rapports

Le système calcule automatiquement:

- **Longueur Totale**: Somme de tous les segments
- **Nombre de Segments**: Count automatique
- **Longueur Moyenne des Segments**: Longueur totale / nombre de segments
- **Locations Traversées**: Liste unique de toutes les salles
- **Racks Utilisés**: Liste unique de tous les racks
- **Types de Câbles**: Liste unique de tous les types utilisés

## Bonnes Pratiques

### Nommage des Références

Utilisez une convention cohérente:
- `PATH-[SOURCE]-[DEST]-[NUM]`: Ex: "PATH-SALA-SALB-001"
- `BB-[SITE1]-[SITE2]-[NUM]`: Pour les backbones
- `MMR-[CLIENT]-[NUM]`: Pour les connexions MMR

### Documentation des Segments

- **Toujours** renseigner la longueur des câbles
- **Toujours** identifier les câbles avec des étiquettes uniques
- Utiliser les **couleurs** pour faciliter l'identification physique
- Documenter les **polarités** pour la fibre optique

### Gestion des Changements

1. Créer un Work Order avant toute modification
2. Documenter l'état "avant" et "après"
3. Mettre à jour les segments affectés
4. Ajouter un Audit Event pour tracer le changement
5. Valider le Work Order après vérification

### Maintenance

- Vérifier régulièrement que les chemins actifs correspondent à la réalité
- Désactiver les chemins qui ne sont plus en service (plutôt que de les supprimer)
- Auditer périodiquement les longueurs réelles vs documentées
- Maintenir à jour les étiquettes de câbles

## Intégration avec Cross-Connects

Un PatchPath peut être lié à un CrossConnect pour une traçabilité complète:

1. Le CrossConnect gère l'aspect commercial et administratif
2. Le PatchPath documente l'implémentation physique détaillée
3. Les deux ensemble fournissent une vue complète

## Dépannage

### Le graphe ne s'affiche pas

- Vérifier que vis-network est chargé (console JavaScript)
- Vérifier qu'il y a au moins un segment dans le chemin
- Essayer de rafraîchir la page

### Les longueurs ne correspondent pas

- La longueur totale d'un PatchPath est calculée à partir des segments
- Mettre à jour les segments pour corriger
- Utiliser la fonction `calculate_total_length()` si nécessaire

### Les connexions ne s'affichent pas dans la topologie

- Vérifier que les chemins sont marqués "Active"
- Vérifier les filtres de site/location
- S'assurer qu'au moins un segment existe

## Support et Ressources

- Documentation API complète: `/api/docs/`
- Schéma de données: Voir `models.py`
- Exemples d'intégration: Voir `visualization.py`
